import java.awt.*;
import java.io.InputStream;

public class TimeBar {
    private final int tempoMassimo;
    private long startTime;

    // ✅ POSIZIONE AGGIORNATA: Sotto lo score, sempre visibile
    private final int barX = 50;  // Allineato con lo score
    private final int barY = 150;  // Sotto lo score (che sarà a y=50 + altezza cifre)
    private final int barWidth = 250; // Leggermente più stretta
    private final int barHeight = 20; // Leggermente più bassa
    private final int[] soglieBonus = {30, 40, 50, 60, 70, 80, 100, 120};
    
    // ✅ FONT ARCADE più piccolo
    private Font arcadeFont;

    public TimeBar(int tempoMassimo) {
        this.tempoMassimo = tempoMassimo;
        this.startTime = System.currentTimeMillis();
        loadArcadeFont();
        System.out.println("⏱️ TimeBar creata con tempo: " + tempoMassimo + "s");
    }
    
    // ✅ CARICA FONT ARCADE
    private void loadArcadeFont() {
        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            if (is != null) {
                arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(Font.BOLD, 12f); // ✅ Più piccolo
            } else {
                arcadeFont = new Font("Monospaced", Font.BOLD, 12);
            }
        } catch (Exception e) {
            arcadeFont = new Font("Monospaced", Font.BOLD, 12);
        }
    }

    public void update() {
        // Questo metodo può essere usato per futuri aggiornamenti
    }

    public int getTempoResiduo() {
        int tempoTrascorso = (int) ((System.currentTimeMillis() - startTime) / 1000);
        return Math.max(0, tempoMassimo - tempoTrascorso);
    }
    
    public int getTempoTrascorso() {
        return (int) ((System.currentTimeMillis() - startTime) / 1000);
    }

    public void draw(Graphics2D g2) {
        int tempoResiduo = getTempoResiduo();
        float percent = (float) tempoResiduo / tempoMassimo;
        int fillWidth = (int) (barWidth * percent);

        // Colore dinamico
        Color barColor = percent > 0.5 ? Color.GREEN : (percent > 0.2 ? Color.ORANGE : Color.RED);

        // Contorno
        g2.setColor(Color.GRAY);
        g2.fillRect(barX, barY, barWidth, barHeight);

        // Riempimento
        g2.setColor(barColor);
        g2.fillRect(barX, barY, fillWidth, barHeight);

        // Bordo
        g2.setColor(Color.BLACK);
        g2.drawRect(barX, barY, barWidth, barHeight);

        // ✅ TEMPO RESIDUO CON FONT ARCADE più piccolo
        g2.setFont(arcadeFont);
        g2.setColor(Color.WHITE);
        g2.drawString("TIME: " + tempoResiduo + "s", barX, barY - 8);

        // Tacche soglie bonus
        g2.setColor(Color.CYAN);
        for (int soglia : soglieBonus) {
            if (soglia < tempoMassimo) {
                int x = barX + (int) ((float) (tempoMassimo - soglia) / tempoMassimo * barWidth);
                g2.drawLine(x, barY, x, barY + barHeight);
            }
        }
    }
}