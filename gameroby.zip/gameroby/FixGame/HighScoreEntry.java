import java.io.Serializable;

/**
 * Represents a single high score entry with player initials and score.
 */
public class HighScoreEntry implements Serializable, Comparable<HighScoreEntry> {
    private static final long serialVersionUID = 1L;
    
    private String initials;
    private int score;
    
    public HighScoreEntry(String initials, int score) {
        this.initials = initials.length() > 3 ? initials.substring(0, 3) : initials;
        this.score = score;
    }
    
    public String getInitials() {
        return initials;
    }
    
    public int getScore() {
        return score;
    }
    
    @Override
    public int compareTo(HighScoreEntry other) {
        // Sort in descending order (highest score first)
        return Integer.compare(other.score, this.score);
    }
    
    @Override
    public String toString() {
        return String.format("%3s  %06d", initials, score);
    }
}

