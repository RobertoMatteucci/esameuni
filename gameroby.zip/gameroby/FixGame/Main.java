import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SoundEffects.stopSound("intro1");
        
        // Creazione del menu e attesa della scelta dell'utente
        Menu menu = new Menu();
        int scelta = menu.waitForMenuResponse();
        
        if (scelta == Menu.EXIT) {
            System.exit(0);
        }
        
        // Creazione della finestra di gioco a schermo intero
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setUndecorated(true); // Rimuove la barra del titolo
        window.setTitle("Fix-it FELIX");
        
        // Imposta la finestra a schermo intero
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        if (gd.isFullScreenSupported()) {
            gd.setFullScreenWindow(window);
        } else {
            window.setExtendedState(JFrame.MAXIMIZED_BOTH);
        }
        
        GamePanel gamePanel = new GamePanel();
        window.add(gamePanel);
        window.pack();
        
        // Assicura che il GamePanel riceva il focus per gli input da tastiera
        gamePanel.setFocusable(true);
        gamePanel.requestFocusInWindow();
        
        // Aggiunta del listener per il tasto ESC direttamente al GamePanel
        gamePanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    System.exit(0);
                }
            }
        });
        
        // Caricamento suoni (gestisce entrambi i percorsi: con e senza /)
        SoundEffects.loadSound("Background", "snd/bgm.wav");

        SoundEffects.loadSound("voice1", "snd/voice1.wav");
        
        SoundEffects.playSoundLoop("Background");
        
        // Timer per le voci
        Timer timer = new Timer(25000, e -> SoundEffects.playSound("voice0"));
        timer.setRepeats(false);
        timer.start();
        
        Timer timer2 = new Timer(6000, e -> SoundEffects.playSound("voice4"));
        timer2.setRepeats(false);
        timer2.start();
        
        window.setVisible(true);
        
        gamePanel.startGameThread();
    }
}