public class LivelloN {

    private int numeroLivello;
    private int finestreDaAggiustare;

    public LivelloN(int numeroLivello) {
        this.numeroLivello = numeroLivello;
        this.finestreDaAggiustare = calcolaFinestre(numeroLivello);
    }

    // Calcola quante finestre devono essere riparate in base al numero del livello
    private int calcolaFinestre(int livello) {
        return (livello % 2 == 0) ? 20 : 18;
    }

    // Restituisce il numero del livello corrente
    public int getNumeroLivello() {
        return numeroLivello;
    }

    // Restituisce quante finestre vanno riparate in questo livello
    public int getFinestreDaAggiustare() {
        return finestreDaAggiustare;
    }

    // Passa al livello successivo e aggiorna il numero di finestre
    public void prossimoLivello() {
        numeroLivello++;
        finestreDaAggiustare = calcolaFinestre(numeroLivello);
    }

    // Verifica se il livello è stato completato
    public boolean isCompletato(int finestreRiparate) {
        return finestreRiparate >= finestreDaAggiustare;
    }
}
