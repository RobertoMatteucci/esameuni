import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

public class DebugDrawer {
    Player player;
    ArrayList<Rectangle> collisionTiles; // Aggiunto il campo per i rettangoli di collisione
    ArrayList<Rectangle> collisioneFinestre; // Aggiunto il campo per i rettangoli di collisione
    


    // Aggiungiamo il parametro collisionTiles nel costruttore
    public DebugDrawer(Player player, ArrayList<Rectangle> collisionTiles, ArrayList<Rectangle> collisioneFinestre) {
        this.player = player;
        this.collisionTiles = collisionTiles;
        this.collisioneFinestre = collisioneFinestre;
    }

    public void draw(Graphics2D g) {
        // Disegna la hitbox del giocatore
        Rectangle hitbox = player.getHitbox();
        Rectangle hitboxMartello = player.getHitboxMartello();
        g.setColor(Color.RED); // Colore per la hitbox del giocatore
        g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height); // Disegna la hitbox
        g.drawRect(hitboxMartello.x, hitboxMartello.y, hitboxMartello.width, hitboxMartello.height); // Disegna la hitbox


        // Disegna i rettangoli di collisione
        g.setColor(Color.RED); // Colore per i rettangoli di collisione
        for (Rectangle rect : collisionTiles) {
            g.drawRect(rect.x, rect.y, rect.width, rect.height); // Disegna ogni rettangolo di collisione
        }

        // Disegna i rettangoli di collisione
        g.setColor(Color.RED); // Colore per i rettangoli di collisione
        for (Rectangle rect : collisioneFinestre) {
            g.drawRect(rect.x, rect.y, rect.width, rect.height); // Disegna ogni rettangolo di collisione
        }
    }
    
}
