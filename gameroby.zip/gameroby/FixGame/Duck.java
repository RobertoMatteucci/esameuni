import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 * Sistema di gestione delle anatre volanti che aumentano la difficoltà del gioco.
 * Le anatre appaiono dal livello 5 in poi e diventano progressivamente più numerose e veloci.
 */
public class Duck {
    
    // Classe interna per rappresentare una singola anatra
    private static class FlyingDuck {
        int x, y;
        int speed;
        boolean movingRight;
        int animationFrame;
        int animationCounter;
        Rectangle hitbox;
        int hitboxOffsetY = 20; 
        
        FlyingDuck(int x, int y, int speed, boolean movingRight) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.movingRight = movingRight;
            this.animationFrame = 0;
            this.animationCounter = 0;
            this.hitbox = new Rectangle(x, y + hitboxOffsetY, 40, 20);
        }
        
        void update() {
            // Movimento orizzontale
            if (movingRight) {
                x += speed;
            } else {
                x -= speed;
            }
            
            // Aggiorna hitbox
            hitbox.x = x;
            hitbox.y = y + hitboxOffsetY;
            
            // Animazione (alterna tra i 2 sprite)
            animationCounter++;
            if (animationCounter >= 8) {
                animationCounter = 0;
                animationFrame = (animationFrame + 1) % 2;
            }
        }
        
        boolean isOffScreen(int screenWidth) {
            return (movingRight && x > screenWidth + 100) || (!movingRight && x < -100);
        }
    }
    
    // Sprite delle anatre
    private BufferedImage duckRight1, duckRight2;
    private BufferedImage duckLeft1, duckLeft2;
    
    // Lista delle anatre attive
    private List<FlyingDuck> ducks;
    
    // Configurazione spawn
    private Random random;
    private long lastSpawnTime;
    private int spawnInterval;
    private int maxDucks;
    private int duckSpeed; // Velocità fissa (non più baseSpeed con random)
    
    // Parametri di gioco
    private GamePanel gp;
    private Player player;
    private boolean isActive;
    private int currentLevel;
    private LivelloN livelloN; // Riferimento alla classe LivelloN
    
    // Altezze possibili per le anatre (diverse "corsie" verticali)
    private int[] possibleHeights = {335, 430, 470, 520, 670, 715};
    
    public Duck(GamePanel gp, Player player, LivelloN livelloN) {
        this.gp = gp;
        this.player = player;
        this.livelloN = livelloN;
        this.ducks = new ArrayList<>();
        this.random = new Random();
        this.isActive = false;
        this.currentLevel = 1;
        
        loadSprites();
        updateDifficultyForLevel(1);
    }
    
    private void loadSprites() {
        try {
            duckRight1 = ImageIO.read(getClass().getResourceAsStream("/Duck/DuckR1.png"));
            duckRight2 = ImageIO.read(getClass().getResourceAsStream("/Duck/DuckR2.png"));
            duckLeft1 = ImageIO.read(getClass().getResourceAsStream("/Duck/DuckL1.png"));
            duckLeft2 = ImageIO.read(getClass().getResourceAsStream("/Duck/DuckL2.png"));
            
            System.out.println("✅ Duck sprites caricati con successo");
        } catch (IOException e) {
            System.err.println("❌ Errore nel caricamento degli sprite delle anatre");
            e.printStackTrace();
        }
    }
    
    /**
     * Aggiorna la difficoltà in base al livello corrente.
     * Progressione stile arcade classico con velocità fisse nei primi livelli.
     */
    private void updateDifficultyForLevel(int level) {
        this.currentLevel = level;
        
        // Le anatre appaiono dal livello 5 in poi
        if (level < 5) {
            isActive = false;
            return;
        }
        
        isActive = true;
        
        // Progressione difficoltà basata sul livello
        // Livelli 5-6: Anatre lente, spawn raro
        // Livelli 7-9: Anatre medie, spawn più frequente
        // Livelli 10+: Anatre veloci, spawn frequente, velocità può variare
        
        if (level <= 6) {
            maxDucks = 1;
            duckSpeed = 3; // Velocità fissa lenta
            spawnInterval = 6000; // 6 secondi
        } else if (level <= 9) {
            maxDucks = 2;
            duckSpeed = 4; // Velocità fissa media
            spawnInterval = 4500; // 4.5 secondi
        } else if (level <= 12) {
            maxDucks = 3;
            duckSpeed = 5; // Velocità fissa veloce
            spawnInterval = 3000; // 3 secondi
        } else if (level <= 15) {
            maxDucks = 3;
            duckSpeed = -1; // -1 indica velocità variabile (4-6)
            spawnInterval = 2500; // 2.5 secondi
        } else {
            // Livelli avanzati: cap massimo
            maxDucks = 4;
            duckSpeed = -1; // Velocità variabile (5-7)
            spawnInterval = 2000; // 2 secondi
        }
        
        System.out.println("Difficoltà anatre aggiornata - Livello: " + level + 
                          " | Max anatre: " + maxDucks + 
                          " | Velocità: " + (duckSpeed == -1 ? "variabile" : duckSpeed) + 
                          " | Spawn intervallo: " + spawnInterval + "ms");
    }
    
    /**
     * Chiamato quando si avanza di livello
     */
    public void setLevel(int level) {
        updateDifficultyForLevel(level);
        
        // Rimuovi tutte le anatre esistenti quando cambia livello
        ducks.clear();
        lastSpawnTime = System.currentTimeMillis();
    }
    
    public void update() {
        if (!isActive) {
            return;
        }
        
        // Aggiorna in base al livello corrente da LivelloN
        if (livelloN != null && livelloN.getNumeroLivello() != currentLevel) {
            setLevel(livelloN.getNumeroLivello());
        }
        
        long currentTime = System.currentTimeMillis();
        
        // Spawna nuove anatre se necessario
        if (ducks.size() < maxDucks && currentTime - lastSpawnTime >= spawnInterval) {
            spawnDuck();
            lastSpawnTime = currentTime;
        }
        
        // Aggiorna tutte le anatre
        Iterator<FlyingDuck> iterator = ducks.iterator();
        while (iterator.hasNext()) {
            FlyingDuck duck = iterator.next();
            duck.update();
            
            // Rimuovi anatre fuori schermo
            if (duck.isOffScreen(gp.screenWidth)) {
                iterator.remove();
                continue;
            }
            
            // Controlla collisione con il player
            if (!player.isPoweredUp() && checkCollision(duck)) {
                player.handleCollisionWithBrick(null);
                iterator.remove();
                System.out.println("🦆 Felix colpito da un'anatra!");
            }
        }
    }
    
    private void spawnDuck() {
        // Determina se l'anatra va da sinistra a destra o viceversa
        boolean movingRight = random.nextBoolean();
        
        // Posizione iniziale
        int x = movingRight ? -80 : gp.screenWidth + 80;
        
        // Scegli un'altezza casuale tra quelle disponibili
        int y = possibleHeights[random.nextInt(possibleHeights.length)];
        
        // Determina velocità
        int speed;
        if (duckSpeed == -1) {
            // Velocità variabile per livelli avanzati
            if (currentLevel <= 15) {
                speed = 4 + random.nextInt(3); // 4-6
            } else {
                speed = 5 + random.nextInt(3); // 5-7
            }
        } else {
            // Velocità fissa per livelli iniziali
            speed = duckSpeed;
        }
        
        FlyingDuck newDuck = new FlyingDuck(x, y, speed, movingRight);
        ducks.add(newDuck);
        
        System.out.println("🦆 Nuova anatra spawned - Direzione: " + 
                          (movingRight ? "→" : "←") + " | Y: " + y + " | Velocità: " + speed);
    }
    
    private boolean checkCollision(FlyingDuck duck) {
        Rectangle playerHitbox = player.getHitbox();
        return duck.hitbox.intersects(playerHitbox);
    }
    
    public void draw(Graphics2D g2) {
        if (!isActive) {
            return;
        }
        
        // Disegna tutte le anatre
        for (FlyingDuck duck : ducks) {
            BufferedImage sprite;
            
            if (duck.movingRight) {
                sprite = (duck.animationFrame == 0) ? duckRight1 : duckRight2;
            } else {
                sprite = (duck.animationFrame == 0) ? duckLeft1 : duckLeft2;
            }
            
            if (sprite != null) {
                // Scala 2x come gli altri sprite del gioco
                g2.drawImage(sprite, duck.x, duck.y, 
                           sprite.getWidth() * 2, sprite.getHeight() * 2, null);
            }
            
            // DEBUG: Disegna hitbox (commentare in produzione)
            g2.setColor(Color.RED);
            g2.draw(duck.hitbox);
        }
    }
    
    public void setActive(boolean active) {
        this.isActive = active;
        if (!active) {
            ducks.clear();
        }
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void cleanup() {
        ducks.clear();
        isActive = false;
    }
    
    /**
     * Resetta il sistema delle anatre (usato per restart)
     */
    public void reset() {
        ducks.clear();
        lastSpawnTime = System.currentTimeMillis();
        updateDifficultyForLevel(1);
    }
}