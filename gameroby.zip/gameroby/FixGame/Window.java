import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Window {
    private int x, y;
    private boolean riparata;
    private Tile finestraRiparata;
    private int lampeggioCounter;
    private boolean visibile;

    public Window(int x, int y) {
        this.x = x;
        this.y = y;
        this.riparata = false;
        this.lampeggioCounter = 15;
        this.visibile = true;
    }

    public void getTileImage() {
        try {
            finestraRiparata = new Tile();
            finestraRiparata.image = ImageIO.read(getClass().getResourceAsStream("/map/aggiustata.png"));


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ripara() {
        this.riparata = true;
        this.visibile = true;
    }

    public void update() {
        if (riparata && lampeggioCounter > 0) {
            if (lampeggioCounter % 2 == 0) {
                visibile = !visibile; // Alterna visibilità
            }
            lampeggioCounter--;
        } else if (lampeggioCounter == 0) {
            visibile = true; // Rimane visibile dopo l'animazione
        }
    }

    public void draw(Graphics2D g2) {
        if (riparata && visibile) {
            g2.drawImage(finestraRiparata.image, x - 18, y - 48, 79, 132, null);
        }
    }
    public boolean isRiparata() {
        return riparata;
    }
}
