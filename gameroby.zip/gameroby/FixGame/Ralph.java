import java.awt.*;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Ralph {

    public int x, y;
    private int dx = 1;
    private Image[] npcImagesLeft;
    private Image[] npcImagesRight;
    private int currentFrame = 0;
    private int frameDelay = 12;
    private int frameCounter = 0;
    private double scaleFactor = 2.0;

    private final int minX = 428;
    private final int maxX = 842;
    private int subFrameCounter = 0;
    private int subFrameSteps = 5;
    private boolean isHittingGround = false;
    private int hitPauseCounter = 0;
    public boolean transition = false;

    private Player felix;
    private ArrayList<Brick> bricks = new ArrayList<>();
    private boolean hasPlayedVoice4 = false;
    private Integer lockedX = null;
    
    // Flag per controllare se Ralph deve essere attivo
    private boolean isActive = true;
    
    // ✅ Sistema di timing accurato per mantenere la velocità originale
    private double accumulatedUpdates = 0.0;
    private static final double UPDATES_PER_FRAME = 1.5; // ✅ Bilanciato per velocità corretta

    public Ralph(Player felix) {
        this.felix = felix;
        x = 644;
        y = 135;

        npcImagesLeft = loadImages(true);
        npcImagesRight = loadImages(false);
    }

    private Image[] loadImages(boolean isLeft) {
        String[] frames = {
            "move10", "move9", "move1", "move2", "move3", "move4", "move5",
            "move6", "move7", "move8", "move9", "move10", "move9", "move10"
        };
        Image[] images = new Image[frames.length];
        for (int i = 0; i < frames.length; i++) {
            images[i] = loadImage("/ralph/" + (isLeft ? frames[i] : frames[frames.length - 1 - i]) + ".png");
        }
        return images;
    }

    private Image loadImage(String path) {
        try {
            return new javax.swing.ImageIcon(getClass().getResource(path)).getImage();
        } catch (Exception e) {
            System.err.println("Failed to load image: " + path);
            return null;
        }
    }

    public void setScaleFactor(double scaleFactor) {
        this.scaleFactor = scaleFactor;
    }
    
    // Metodo per fermare Ralph durante le cutscene
    public void setActive(boolean active) {
        this.isActive = active;
        if (!active) {
            accumulatedUpdates = 0.0; // Reset timing quando disattivato
        }
    }
    
    // Metodo per fermare completamente Ralph e pulire i mattoni
    public void stopAndClear() {
        isActive = false;
        bricks.clear();
        accumulatedUpdates = 0.0;
    }

    public void draw(Graphics2D g2) {
        if (!isActive || transition) {
            return;
        }

        Image currentImage = dx > 0 ? npcImagesRight[currentFrame] : npcImagesLeft[currentFrame];

        if (currentImage != null) {
            int width = (int) (currentImage.getWidth(null) * scaleFactor);
            int height = (int) (currentImage.getHeight(null) * scaleFactor);
            g2.drawImage(currentImage, x, y, width, height, null);
        }

        for (Brick brick : bricks) {
            brick.draw(g2);
        }
    }

    public void update() {
        if (!isActive) {
            return;
        }
        
        // ✅ Accumula updates per mantenere il timing originale
        accumulatedUpdates += UPDATES_PER_FRAME;
        
        // Esegui tutti gli updates accumulati
        while (accumulatedUpdates >= 1.0) {
            updateGame();
            accumulatedUpdates -= 1.0;
        }
    }

    private void updateGame() {
        boolean isFrameToLock = (currentFrame >= 3 && currentFrame <= 6);

        if (currentFrame == 1 || currentFrame == 2 || currentFrame == 7 || currentFrame == 8) {
            x += dx;
        }

        if (x < minX || x > maxX) {
            dx = -dx;
            lockedX = null;
        }

        if ((currentFrame >= 3 && currentFrame <= 6) || (currentFrame >= 9 && currentFrame <= 10)) {
            if (subFrameCounter < subFrameSteps) {
                lockedX = x;
                subFrameCounter++;
            } else {
                subFrameCounter = 0;
            }
        }

        if (currentFrame == 10 && !hasPlayedVoice4) {
            SoundEffects.playSound("voice4");
            hasPlayedVoice4 = true;
        }

        if (currentFrame != 10) {
            hasPlayedVoice4 = false;
        }

        if (isFrameToLock && !isHittingGround) {
            isHittingGround = true;
            hitPauseCounter = 12;
            // ✅ NON rilasciare i mattoni immediatamente!
            // Li rilasceremo quando i pugni toccano effettivamente terra
        }

        if (isHittingGround) {
            hitPauseCounter--;
            
            // ✅ SINCRONIZZAZIONE: Rilascia i mattoni quando i pugni toccano terra
            // Frame 4, 5, 6 sono quando Ralph colpisce, ma rilasciamo dopo un ritardo
            if (hitPauseCounter == 8 && currentFrame == 4) { // Primo colpo
                releaseBrick(1);
            }
            if (hitPauseCounter == 5 && currentFrame == 5) { // Secondo colpo
                releaseBrick(2);
            }
            if (hitPauseCounter == 2 && currentFrame == 6) { // Terzo colpo (casuale)
                releaseBrick(3);
            }
            
            if (hitPauseCounter <= 0) {
                isHittingGround = false;
            }
        }

        for (Brick brick : bricks) {
            brick.update();
            if (brick.brickGetHitbox().intersects(felix.getHitbox())) {
                felix.handleCollisionWithBrick(brick);
            }
        }

        bricks.removeIf(Brick::isOutOfScreen);

        frameCounter++;
        if (frameCounter >= frameDelay) {
            currentFrame = (currentFrame + 1) % npcImagesLeft.length;
            frameCounter = 0;
        }
    }

    // ✅ NUOVO METODO: Rilascia un mattone alla volta sincronizzato con l'animazione
    private void releaseBrick(int brickNumber) {
        int offset1 = dx < 0 ? 115 : 20;
        int offset2 = dx < 0 ? 20 : 115;
        int randomOffset = ThreadLocalRandom.current().nextInt(20, 115);

        switch (brickNumber) {
            case 1: // Primo mattone
                bricks.add(new Brick(x + offset1, y + 130));
                SoundEffects.playSound("block");
                break;
            case 2: // Secondo mattone
                bricks.add(new Brick(x + offset2, y + 130));
                SoundEffects.playSound("block");
                break;
            case 3: // Terzo mattone (casuale)
                bricks.add(new Brick(x + randomOffset, y + 130));
                SoundEffects.playSound("block");
                break;
        }
    }
    
    public void cleanup() {
        bricks.clear();
        accumulatedUpdates = 0.0;
        frameCounter = 0;
        currentFrame = 0;
        x = 644;
        y = 135;
        dx = 1;
    }
}