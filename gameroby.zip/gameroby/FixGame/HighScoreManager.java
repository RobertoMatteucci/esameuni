import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages high scores with player initials.
 * Stores top 6 scores in a file with full backward compatibility.
 */
public class HighScoreManager {
    private static final String FILE_PATH = "highscores.dat";
    private static final String LEGACY_FILE_PATH = "highscore.dat";
    private static final int MAX_SCORES = 6;
    
    /**
     * Loads all high scores from the file.
     * Attempts to migrate from legacy format if new format doesn't exist.
     * @return List of high score entries, sorted by score (highest first)
     */
    @SuppressWarnings("unchecked")
    public static List<HighScoreEntry> loadHighScores() {
        List<HighScoreEntry> scores = new ArrayList<>();
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            scores = (List<HighScoreEntry>) ois.readObject();
        } catch (FileNotFoundException e) {
            // Try to migrate from legacy file
            int legacyScore = loadLegacyHighScore();
            if (legacyScore > 0) {
                scores.add(new HighScoreEntry("???", legacyScore));
                initializeDefaultScores(scores);
                saveHighScores(scores);
            } else {
                // No legacy file, initialize with defaults
                initializeDefaultScores(scores);
            }
        } catch (IOException | ClassNotFoundException e) {
            // Error reading file, initialize with defaults
            initializeDefaultScores(scores);
        }
        
        return scores;
    }
    
    /**
     * Saves the high scores to file.
     * @param scores List of high score entries to save
     */
    public static void saveHighScores(List<HighScoreEntry> scores) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(scores);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Adds a new score to the high score list if it qualifies.
     * @param initials Player's initials (max 3 characters)
     * @param score The score achieved
     * @return The position in the high score list (1-6), or -1 if it didn't qualify
     */
    public static int addHighScore(String initials, int score) {
        List<HighScoreEntry> scores = loadHighScores();
        HighScoreEntry newEntry = new HighScoreEntry(initials, score);
        
        scores.add(newEntry);
        Collections.sort(scores);
        
        // Find the position of the new entry
        int position = -1;
        for (int i = 0; i < Math.min(scores.size(), MAX_SCORES); i++) {
            if (scores.get(i) == newEntry) {
                position = i + 1;
                break;
            }
        }
        
        // Keep only top MAX_SCORES
        if (scores.size() > MAX_SCORES) {
            scores = new ArrayList<>(scores.subList(0, MAX_SCORES));
        }
        
        saveHighScores(scores);
        return position;
    }
    
    /**
     * Checks if a score qualifies for the high score list.
     * @param score The score to check
     * @return true if the score qualifies for the top 6
     */
    public static boolean isHighScore(int score) {
        if (score <= 0) {
            return false;
        }
        
        List<HighScoreEntry> scores = loadHighScores();
        
        if (scores.size() < MAX_SCORES) {
            return true; // Always qualify if less than 6 scores
        }
        
        // Check if score is higher than the lowest high score
        return score > scores.get(scores.size() - 1).getScore();
    }
    
    /**
     * Initializes the high score list with default entries.
     * @param scores The list to initialize
     */
    private static void initializeDefaultScores(List<HighScoreEntry> scores) {
        if (scores.isEmpty()) {
            scores.add(new HighScoreEntry("AAA", 50000));
            scores.add(new HighScoreEntry("BBB", 40000));
            scores.add(new HighScoreEntry("CCC", 30000));
            scores.add(new HighScoreEntry("DDD", 20000));
            scores.add(new HighScoreEntry("EEE", 10000));
            scores.add(new HighScoreEntry("FFF", 5000));
        }
    }
    
    /**
     * Legacy method for backward compatibility with TileManager.
     * Returns the highest score from the new system.
     * @return The highest score, or 0 if no scores exist
     */
    public static int loadHighScore() {
        List<HighScoreEntry> scores = loadHighScores();
        return scores.isEmpty() ? 0 : scores.get(0).getScore();
    }
    
    /**
     * Legacy method for backward compatibility with TileManager.
     * Saves a score without initials (uses "CPU" as placeholder).
     * Only saves if the score qualifies for the high score list.
     * @param score The score to save
     */
    public static void saveHighScore(int score) {
        if (isHighScore(score)) {
            addHighScore("CPU", score);
        }
    }
    
    /**
     * Checks if a new score beats the current high score.
     * Compatible with TileManager's comparison pattern.
     * @param newScore The score to check
     * @return true if newScore is higher than the current high score
     */
    public static boolean isNewHighScore(int newScore) {
        return newScore > loadHighScore();
    }
    
    /**
     * Attempts to load the legacy single high score from old file format.
     * @return The legacy high score, or 0 if file doesn't exist or error occurs
     */
    private static int loadLegacyHighScore() {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(LEGACY_FILE_PATH))) {
            return dis.readInt();
        } catch (IOException e) {
            return 0;
        }
    }
    
    /**
     * Clears all high scores and resets to defaults.
     * Useful for testing or reset functionality.
     */
    public static void resetHighScores() {
        List<HighScoreEntry> scores = new ArrayList<>();
        initializeDefaultScores(scores);
        saveHighScores(scores);
    }
    
    /**
     * Gets the rank position a score would achieve.
     * @param score The score to check
     * @return The rank (1-6) the score would achieve, or -1 if it wouldn't qualify
     */
    public static int getScoreRank(int score) {
        List<HighScoreEntry> scores = loadHighScores();
        
        int rank = 1;
        for (HighScoreEntry entry : scores) {
            if (score > entry.getScore()) {
                return rank;
            }
            rank++;
            if (rank > MAX_SCORES) {
                return -1;
            }
        }
        
        return rank <= MAX_SCORES ? rank : -1;
    }
    
    /**
     * Gets the lowest qualifying score in the high score list.
     * Useful for displaying the score to beat.
     * @return The lowest high score, or 0 if list is not full
     */
    public static int getLowestHighScore() {
        List<HighScoreEntry> scores = loadHighScores();
        if (scores.size() >= MAX_SCORES) {
            return scores.get(MAX_SCORES - 1).getScore();
        }
        return 0;
    }
}