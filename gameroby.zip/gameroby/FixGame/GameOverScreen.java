import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Game Over screen with high score display.
 * Old-style arcade presentation - fully compatible with unified game system.
 */
public class GameOverScreen {
    private GamePanel gp;
    private int finalScore;
    
    // Screen states
    private static final int STATE_HIGH_SCORE_DISPLAY = 0;
    private static final int STATE_ENTER_INITIALS = 1;
    private static final int STATE_FINAL_MENU = 2;
    private int currentState = STATE_HIGH_SCORE_DISPLAY;
    
    // Menu selection
    private int menuSelection = 0; // 0 = Restart, 1 = Quit
    private long lastMenuBlink = 0;
    
    // High score display
    private List<HighScoreEntry> highScores;
    private boolean isNewHighScore = false;
    private int newScorePosition = -1;
    
    // Initial entry
    private char[] initials = {'A', 'A', 'A'};
    private int currentInitialIndex = 0;
    private long lastBlinkTime = 0;
    private boolean cursorVisible = true;
    
    // Font
    private Font arcadeFont;
    private BufferedImage[] digitImages = new BufferedImage[10];
    
    // State flags
    private boolean enterPressed = false;
    private boolean restartGame = false;
    private boolean quitGame = false;
    
    public GameOverScreen(GamePanel gp, int finalScore, int playerX, int playerY) {
        this.gp = gp;
        this.finalScore = finalScore;
        System.out.println("GameOverScreen created with score: " + finalScore);
        loadResources();
        
        // Pre-check if this is a new high score
        isNewHighScore = HighScoreManager.isHighScore(finalScore);
        if (isNewHighScore) {
            newScorePosition = HighScoreManager.getScoreRank(finalScore);
            System.out.println("New high score! Rank: " + newScorePosition);
        }
        
        // Load high scores immediately
        highScores = HighScoreManager.loadHighScores();
        
        // If it's a new high score, transition to initial entry after a brief pause
        if (isNewHighScore) {
            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    if (currentState == STATE_HIGH_SCORE_DISPLAY) {
                        currentState = STATE_ENTER_INITIALS;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
    
    private void loadResources() {
        // Load arcade font
        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is);
            System.out.println("Loaded arcade font");
        } catch (Exception e) {
            System.err.println("Failed to load arcade font, using fallback");
            arcadeFont = new Font("Monospaced", Font.BOLD, 20);
        }
        
        // Load digit images for score display
        for (int i = 0; i < 10; i++) {
            try {
                digitImages[i] = ImageIO.read(getClass().getResourceAsStream("/map/digits" + i + ".png"));
                if (digitImages[i] != null) {
                    System.out.println("Loaded digit image: " + i);
                }
            } catch (Exception e) {
                System.err.println("Failed to load digit image: " + i);
            }
        }
    }
    
    public void update() {
        if (currentState == STATE_ENTER_INITIALS) {
            updateInitialEntry();
        } else if (currentState == STATE_FINAL_MENU) {
            updateFinalMenu();
        }
    }
    
    private void updateFinalMenu() {
        // Blink cursor
        if (System.currentTimeMillis() - lastMenuBlink > 300) {
            lastMenuBlink = System.currentTimeMillis();
        }
    }
    
    private void updateInitialEntry() {
        // Blink cursor
        if (System.currentTimeMillis() - lastBlinkTime > 500) {
            cursorVisible = !cursorVisible;
            lastBlinkTime = System.currentTimeMillis();
        }
    }
    
    public void draw(Graphics2D g2) {
        // Black background
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        
        if (currentState == STATE_HIGH_SCORE_DISPLAY || currentState == STATE_ENTER_INITIALS) {
            drawHighScoreScreen(g2);
        } else if (currentState == STATE_FINAL_MENU) {
            drawFinalMenu(g2);
        }
    }
    
    private void drawHighScoreScreen(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        
        int centerX = gp.screenWidth / 2;
        int startY = 150;
        
        // Draw "GAME OVER" title
        g2.setFont(arcadeFont.deriveFont(48f));
        String gameOverText = "GAME OVER";
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(gameOverText);
        
        // Draw shadow
        g2.setColor(new Color(100, 0, 0));
        g2.drawString(gameOverText, centerX - textWidth / 2 + 3, startY + 3);
        
        // Draw main text
        g2.setColor(Color.RED);
        g2.drawString(gameOverText, centerX - textWidth / 2, startY);
        
        // Draw "YOUR SCORE"
        startY += 100;
        g2.setFont(arcadeFont.deriveFont(24f));
        String yourScoreText = "YOUR SCORE";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(yourScoreText);
        g2.setColor(Color.WHITE);
        g2.drawString(yourScoreText, centerX - textWidth / 2, startY);
        
        // Draw the player's score using digit images
        startY += 60;
        drawScoreWithDigits(g2, finalScore, centerX - 165, startY);
        
        // Draw "HIGH SCORES" header
        startY += 120;
        g2.setFont(arcadeFont.deriveFont(28f));
        String highScoreText = "HIGH SCORES";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(highScoreText);
        g2.setColor(Color.YELLOW);
        g2.drawString(highScoreText, centerX - textWidth / 2, startY);
        
        // Draw high score table
        startY += 60;
        drawHighScoreTable(g2, centerX, startY);
        
        // Draw initial entry prompt if applicable
        if (currentState == STATE_ENTER_INITIALS) {
            drawInitialEntry(g2, centerX, startY + 400);
        } else if (currentState == STATE_HIGH_SCORE_DISPLAY && !isNewHighScore) {
            // Show "Press ENTER to continue" if not a new high score
            int y = startY + 400;
            g2.setFont(arcadeFont.deriveFont(16f));
            String continueText = "PRESS ENTER TO CONTINUE";
            fm = g2.getFontMetrics();
            textWidth = fm.stringWidth(continueText);
            if ((System.currentTimeMillis() / 500) % 2 == 0) {
                g2.setColor(Color.GRAY);
                g2.drawString(continueText, centerX - textWidth / 2, y);
            }
        }
    }
    
    private void drawScoreWithDigits(Graphics2D g2, int score, int x, int y) {
        String scoreString = String.format("%06d", score);
        int digitWidth = 55;
        
        for (int i = 0; i < scoreString.length(); i++) {
            int digit = Character.getNumericValue(scoreString.charAt(i));
            if (digit >= 0 && digit <= 9 && digitImages[digit] != null) {
                g2.drawImage(digitImages[digit], x + i * digitWidth, y, 50, 60, null);
            } else {
                // Fallback: draw text if image not available
                g2.setFont(arcadeFont.deriveFont(40f));
                g2.setColor(Color.WHITE);
                g2.drawString(String.valueOf(digit), x + i * digitWidth, y + 45);
            }
        }
    }
    
    private void drawHighScoreTable(Graphics2D g2, int centerX, int startY) {
        g2.setFont(arcadeFont.deriveFont(20f));
        
        if (highScores == null) {
            highScores = HighScoreManager.loadHighScores();
        }
        
        int lineHeight = 50;
        for (int i = 0; i < Math.min(highScores.size(), 6); i++) {
            HighScoreEntry entry = highScores.get(i);
            int y = startY + i * lineHeight;
            
            // Highlight new high score entry
            boolean isNewEntry = isNewHighScore && (i == newScorePosition - 1) && 
                                 (currentState == STATE_ENTER_INITIALS || entry.getScore() == finalScore);
            
            if (isNewEntry) {
                g2.setColor(Color.GREEN);
            } else {
                g2.setColor(Color.CYAN);
            }
            
            // Draw rank
            String rank = String.format("%d.", i + 1);
            g2.drawString(rank, centerX - 300, y);
            
            // Draw initials
            String initialsText;
            if (isNewEntry && currentState == STATE_ENTER_INITIALS) {
                initialsText = new String(initials);
            } else {
                initialsText = entry.getInitials();
            }
            g2.drawString(initialsText, centerX - 220, y);
            
            // Draw score with digit images
            drawScoreWithDigits(g2, entry.getScore(), centerX - 80, y - 35);
        }
    }
    
    private void drawInitialEntry(Graphics2D g2, int centerX, int y) {
        g2.setFont(arcadeFont.deriveFont(20f));
        String promptText = "ENTER YOUR INITIALS";
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(promptText);
        
        // Blink the entire prompt
        if ((System.currentTimeMillis() / 300) % 2 == 0) {
            g2.setColor(Color.YELLOW);
            g2.drawString(promptText, centerX - textWidth / 2, y);
        }
        
        // Draw instructions
        y += 50;
        g2.setFont(arcadeFont.deriveFont(14f));
        g2.setColor(Color.GRAY);
        String instructions = "USE UP/DOWN TO CHANGE LETTER";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(instructions);
        g2.drawString(instructions, centerX - textWidth / 2, y);
        
        y += 30;
        String instructions2 = "LEFT/RIGHT TO MOVE, ENTER TO CONFIRM";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(instructions2);
        g2.drawString(instructions2, centerX - textWidth / 2, y);
    }
    
    private void drawFinalMenu(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        
        int centerX = gp.screenWidth / 2;
        int startY = gp.screenHeight / 2 - 100;
        
        // Draw "GAME OVER" title
        g2.setFont(arcadeFont.deriveFont(48f));
        String gameOverText = "GAME OVER";
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(gameOverText);
        g2.setColor(Color.RED);
        g2.drawString(gameOverText, centerX - textWidth / 2, startY);
        
        startY += 120;
        
        // Draw menu options
        g2.setFont(arcadeFont.deriveFont(28f));
        
        // Restart Game option
        String restartText = "RESTART GAME";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(restartText);
        if (menuSelection == 0) {
            // Selected - draw with arrow and blink
            if ((System.currentTimeMillis() / 300) % 2 == 0) {
                g2.setColor(Color.YELLOW);
                g2.drawString("> " + restartText + " <", centerX - textWidth / 2 - 40, startY);
            }
        } else {
            g2.setColor(Color.WHITE);
            g2.drawString(restartText, centerX - textWidth / 2, startY);
        }
        
        startY += 80;
        
        // Quit Game option
        String quitText = "QUIT GAME";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(quitText);
        if (menuSelection == 1) {
            // Selected - draw with arrow and blink
            if ((System.currentTimeMillis() / 300) % 2 == 0) {
                g2.setColor(Color.YELLOW);
                g2.drawString("> " + quitText + " <", centerX - textWidth / 2 - 40, startY);
            }
        } else {
            g2.setColor(Color.WHITE);
            g2.drawString(quitText, centerX - textWidth / 2, startY);
        }
        
        // Draw instructions
        startY += 120;
        g2.setFont(arcadeFont.deriveFont(16f));
        g2.setColor(Color.GRAY);
        String instructions = "USE UP/DOWN TO SELECT, ENTER TO CONFIRM";
        fm = g2.getFontMetrics();
        textWidth = fm.stringWidth(instructions);
        g2.drawString(instructions, centerX - textWidth / 2, startY);
    }
    
    // Input handling methods
    public void handleKeyPress(int keyCode) {
        if (currentState == STATE_ENTER_INITIALS) {
            handleInitialInput(keyCode);
        } else if (currentState == STATE_HIGH_SCORE_DISPLAY) {
            // Enter to go to final menu
            if (keyCode == java.awt.event.KeyEvent.VK_ENTER) {
                currentState = STATE_FINAL_MENU;
            }
        } else if (currentState == STATE_FINAL_MENU) {
            handleFinalMenuInput(keyCode);
        }
    }
    
    private void handleFinalMenuInput(int keyCode) {
        switch (keyCode) {
            case java.awt.event.KeyEvent.VK_UP:
                menuSelection = 0;
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_DOWN:
                menuSelection = 1;
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_ENTER:
                if (menuSelection == 0) {
                    restartGame = true;
                    playSound("hammer");
                } else {
                    quitGame = true;
                    playSound("hammer");
                }
                break;
        }
    }
    
    private void handleInitialInput(int keyCode) {
        switch (keyCode) {
            case java.awt.event.KeyEvent.VK_UP:
                initials[currentInitialIndex]++;
                if (initials[currentInitialIndex] > 'Z') {
                    initials[currentInitialIndex] = 'A';
                }
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_DOWN:
                initials[currentInitialIndex]--;
                if (initials[currentInitialIndex] < 'A') {
                    initials[currentInitialIndex] = 'Z';
                }
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_LEFT:
                currentInitialIndex--;
                if (currentInitialIndex < 0) {
                    currentInitialIndex = 0;
                }
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_RIGHT:
                currentInitialIndex++;
                if (currentInitialIndex > 2) {
                    currentInitialIndex = 2;
                }
                playSound("jump");
                break;
                
            case java.awt.event.KeyEvent.VK_ENTER:
                // Save the high score
                String playerInitials = new String(initials);
                int position = HighScoreManager.addHighScore(playerInitials, finalScore);
                System.out.println("High score saved: " + playerInitials + " - " + finalScore + " (Position: " + position + ")");
                highScores = HighScoreManager.loadHighScores();
                currentState = STATE_FINAL_MENU;
                playSound("hammer");
                break;
        }
    }
    
    private void playSound(String soundName) {
        try {
            SoundEffects.playSound(soundName);
        } catch (Exception e) {
            // Sound system might not be available, ignore
        }
    }
    
    public boolean isEnterPressed() {
        return enterPressed;
    }
    
    public boolean shouldRestartGame() {
        return restartGame;
    }
    
    public boolean shouldQuitGame() {
        return quitGame;
    }
    
    public int getCurrentState() {
        return currentState;
    }
}