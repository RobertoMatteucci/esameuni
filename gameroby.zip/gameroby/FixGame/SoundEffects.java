import java.io.File;
import java.util.HashMap;
import javax.sound.sampled.*;

public class SoundEffects {

    // Mappa per memorizzare i suoni caricati
    private static HashMap<String, Clip> soundEffects = new HashMap<>();

    // Metodo per caricare un suono nella mappa
    public static void loadSound(String key, String filePath) {
        try {
            File audioFile = new File(filePath);
            if (!audioFile.exists()) {
                throw new IllegalArgumentException("File audio non trovato: " + filePath);
            }

            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);

            soundEffects.put(key, clip); // Aggiungi il suono alla mappa
            System.out.println("Suono caricato: " + key);
        } catch (Exception e) {
            System.out.println("Errore nel caricamento del suono: " + key);
            e.printStackTrace();
        }
    }

    // Metodo per riprodurre un suono dalla mappa
    public static void playSound(String key) {
        Clip clip = soundEffects.get(key);
        if (clip == null) {
            System.out.println("Effetto sonoro non trovato nella mappa: " + key);
            return;
        }
        if (clip.isRunning()) {
            clip.stop(); // Ferma la riproduzione corrente
        }
        clip.setFramePosition(0); // Riavvia dal primo frame
        clip.start(); // Avvia la riproduzione
        System.out.println("Riproduzione suono: " + key);
    }

    // Metodo per riprodurre un suono in loop
    public static void playSoundLoop(String key) {
        Clip clip = soundEffects.get(key);
        if (clip == null) {
            System.out.println("Effetto sonoro non trovato nella mappa: " + key);
            return;
        }
        if (clip.isRunning()) {
            clip.stop(); // Ferma il loop corrente
        }
        clip.setFramePosition(0); // Riavvia dal primo frame
        clip.loop(Clip.LOOP_CONTINUOUSLY); // Imposta il loop continuo
        System.out.println("Riproduzione in loop suono: " + key);
    }

    // Metodo per fermare un suono specifico
    public static void stopSound(String key) {
        Clip clip = soundEffects.get(key);
        if (clip != null && clip.isRunning()) {
            clip.stop();
            System.out.println("Riproduzione fermata per suono: " + key);
        }
    }

    // Metodo per chiudere tutti i suoni e liberare le risorse
    public static void closeAll() {
        for (Clip clip : soundEffects.values()) {
            clip.stop();
            clip.close();
        }
        soundEffects.clear(); // Svuota la mappa
        System.out.println("Tutti i suoni chiusi e risorse liberate.");
    }
}
