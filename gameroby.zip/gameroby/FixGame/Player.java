import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Player extends Entity {

    GamePanel gp;
    KeyHandler keyH;
    int x;
    int y;
    // Variabili per l'animazione
    private int animationFrame = 0;
    private int frameCounter = 0;
    private final int animationSpeed = 5;
    private boolean isMoving = false;

    // Durata durante la quale la collisione con i davanzali è disabilitata
    private boolean ignoreCollision = false;
    private int ignoreCollisionCounter = 0;
    private final int ignoreCollisionDuration = 10;

    // Variabili per il cambio di direzione
    private boolean isChangingDirection = false;
    private int changeDirectionCounter = 0;
    private final int changeDirectionDuration = 3;

    // Variabili per l'animazione di "fix" (space)
    private boolean isFixing = false;
    private int fixAnimationCount = 0;
    private final int maxFixAnimations = 4;

    // Variabili per il salto
    private boolean isJumping = false;
    private boolean isFalling = false;
    private boolean isGoingDown = false;
    private int startY = 0;
    private final int jumpHeight = 130;
    private final int jumpSpeed = 11;
    private final int fallSpeed = 10;

    //Gestione delle collisioni
    private CollisionManager collisionManager;
    private Rectangle hitbox;
    private final int hitboxWidth = 20;
    private final int hitboxHeight = 60;
    private final int offsetXLeft = 40;
    private final int offsetXRight = 4;

    private final int offsetXMartello = 39;
    private final int offsetYMartello = 50;
    private final int hitboxMartelloWidth = 18;
    private final int hitboxMartelloHeight = 15;
    private Rectangle hitboxMartello;

    // gestione Morte
    private long deathTimeStart = 0;
    private final int IMMUNITY_TIME = 4000;
    private boolean isDead = false;
    private int deathAnimationFrame = 0;
    private int deathAnimationCounter = 0;
    private final int deathAnimationSpeed = 20;
    private final int maxDeathFrames = 4;
    boolean finalDeath = false;
    boolean felixFinalDeath = false;

    // ✅ ANIMAZIONE MORTE FINALE
    private int finalDeathAnimationFrame = 0;
    private int finalDeathAnimationCounter = 0;
    private final int finalDeathAnimationSpeed = 15;
    private final int maxFinalDeathFrames = 9;
    private BufferedImage[] finalDeathSprites = new BufferedImage[9];
    private boolean finalDeathAnimationComplete = false;

    //gestione vite
    private boolean isFelixHead1Visible = true;
    private boolean isFelixHead2Visible = true;
    private boolean isFelixHead3Visible = true;
    int felixHealth = 4;

    private boolean felixVisible = true;
    private long lastBlinkTime = 0;

    // Flag per controllare se Felix deve essere attivo
    private boolean isActive = true;

    // ✅ NUOVE VARIABILI PER L'ANIMAZIONE DI MANGIARE LA TORTA
    private boolean isEating = false;
    private int eatingAnimationFrame = 0;
    private int eatingAnimationCounter = 0;
    private final int eatingAnimationSpeed = 8;
    private final int maxEatingFrames = 7;

    // ✅ POTENZIAMENTO INVULNERABILITÀ
    private boolean isPoweredUp = false;
    private long powerUpStartTime = 0;
    private final int POWERUP_DURATION = 10000;
    private long lastPowerUpBlinkTime = 0;
    private boolean powerUpVisible = true;

    public Player(GamePanel gp, KeyHandler keyH, CollisionManager collisionManager) {
        this.gp = gp;
        this.keyH = keyH;
        this.collisionManager = collisionManager;

        setDefaultValues();
        getPlayerImage();

        hitbox = new Rectangle(x + offsetXRight, y, hitboxWidth, hitboxHeight);
        hitboxMartello = new Rectangle();

    }

    public void setDefaultValues() {
        x = 1052;
        y = 764;
        speed = 4;
        direction = "left";
    }

    public void getPlayerImage() {
        try {
            left1 = ImageIO.read(getClass().getResourceAsStream("/felix/Left1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/felix/Left2.png"));
            left3 = ImageIO.read(getClass().getResourceAsStream("/felix/Left3.png"));

            right1 = ImageIO.read(getClass().getResourceAsStream("/felix/Right1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/felix/Right2.png"));
            right3 = ImageIO.read(getClass().getResourceAsStream("/felix/Right3.png"));

            steadyR = ImageIO.read(getClass().getResourceAsStream("/felix/StaticR.png"));
            steadyL = ImageIO.read(getClass().getResourceAsStream("/felix/StaticL.png"));

            fixR = ImageIO.read(getClass().getResourceAsStream("/felix/FixitR1.png"));
            fixL = ImageIO.read(getClass().getResourceAsStream("/felix/FixitL1.png"));

            changeDirectionL = ImageIO.read(getClass().getResourceAsStream("/felix/DirectionChangeL.png"));
            changeDirectionR = ImageIO.read(getClass().getResourceAsStream("/felix/DirectionChangeR.png"));

            jumpL = ImageIO.read(getClass().getResourceAsStream("/felix/JumpL.png"));
            jumpR = ImageIO.read(getClass().getResourceAsStream("/felix/JumpR.png"));

            goingDownL = ImageIO.read(getClass().getResourceAsStream("/felix/DownL.png"));
            goingDownR = ImageIO.read(getClass().getResourceAsStream("/felix/DownR.png"));

            death1 = ImageIO.read(getClass().getResourceAsStream("/felix/death1.png"));
            death2 = ImageIO.read(getClass().getResourceAsStream("/felix/death2.png"));
            death3 = ImageIO.read(getClass().getResourceAsStream("/felix/death3.png"));
            death4 = ImageIO.read(getClass().getResourceAsStream("/felix/death4.png"));

            felixHead1 = ImageIO.read(getClass().getResourceAsStream("/felix/felixHead.png"));
            felixHead2 = ImageIO.read(getClass().getResourceAsStream("/felix/felixHead.png"));
            felixHead3 = ImageIO.read(getClass().getResourceAsStream("/felix/felixHead.png"));

            // ✅ CARICA GLI SPRITE PER MANGIARE LA TORTA
            for (int i = 0; i < maxEatingFrames; i++) {
                eatingLeft[i] = ImageIO.read(getClass().getResourceAsStream("/felix/TortaL" + (i + 1) + ".png"));
                eatingRight[i] = ImageIO.read(getClass().getResourceAsStream("/felix/TortaR" + (i + 1) + ".png"));
            }

            // ✅ CARICA GLI SPRITE DELLA MORTE FINALE
            for (int i = 0; i < maxFinalDeathFrames; i++) {
                finalDeathSprites[i] = ImageIO.read(getClass().getResourceAsStream("/felix/FDeath" + (i + 1) + ".png"));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        if (!isActive) {
            return;
        }

        isMoving = false;

        // ✅ GESTIONE ANIMAZIONE MORTE FINALE
        if (finalDeath && felixFinalDeath) {
            finalDeathAnimationCounter++;
            if (finalDeathAnimationCounter >= finalDeathAnimationSpeed) {
                finalDeathAnimationCounter = 0;
                finalDeathAnimationFrame++;

                if (finalDeathAnimationFrame >= maxFinalDeathFrames) {
                    finalDeathAnimationFrame = maxFinalDeathFrames - 1;
                    finalDeathAnimationComplete = true;
                }
            }
            ignoreCollision = true;
            return;
        }

        // ✅ GESTIONE ANIMAZIONE MANGIARE TORTA (blocca tutto il resto)
        if (isEating) {
            eatingAnimationCounter++;
            if (eatingAnimationCounter >= eatingAnimationSpeed) {
                eatingAnimationCounter = 0;
                eatingAnimationFrame++;

                if (eatingAnimationFrame >= maxEatingFrames) {
                    isEating = false;
                    eatingAnimationFrame = 0;
                    
                    isPoweredUp = true;
                    powerUpStartTime = System.currentTimeMillis();
                    lastPowerUpBlinkTime = System.currentTimeMillis();
                    
                    System.out.println("Felix è ora invulnerabile per " + (POWERUP_DURATION / 1000) + " secondi!");
                }
            }
            return;
        }

        // ✅ GESTIONE EFFETTO VISIVO POTENZIAMENTO (lampeggio)
        if (isPoweredUp) {
            long currentTime = System.currentTimeMillis();
            
            if (currentTime - powerUpStartTime >= POWERUP_DURATION) {
                isPoweredUp = false;
                powerUpVisible = true;
                System.out.println("Potenziamento terminato!");
            } else {
                if (currentTime - lastPowerUpBlinkTime >= 150) {
                    powerUpVisible = !powerUpVisible;
                    lastPowerUpBlinkTime = currentTime;
                }
            }
        }

        if (isDead) {
            if (deathTimeStart == 0) {
                deathTimeStart = System.currentTimeMillis();
            }

            deathAnimationCounter++;
            if (deathAnimationCounter >= deathAnimationSpeed) {
                deathAnimationCounter = 0;
                deathAnimationFrame++;

                if (deathAnimationFrame >= maxDeathFrames) {
                    isDead = false;
                }
            }
            return;
        }

        if (isDead && (System.currentTimeMillis() - deathTimeStart) < IMMUNITY_TIME) {
            return;
        }

        if (keyH.spacePressed && !isFixing && !isJumping && !isFalling && !isGoingDown) {
            isFixing = true;
            fixAnimationCount = 0;
            SoundEffects.playSound("hammer");
        }

        if (isFixing) {
            hitboxMartello = new Rectangle(x + offsetXMartello, y + offsetYMartello, hitboxMartelloWidth, hitboxMartelloHeight);
            frameCounter++;
            if (direction == "left") {
                hitboxMartello.x -= offsetXLeft - 7;
            }
            if (frameCounter >= animationSpeed) {
                frameCounter = 0;
                fixAnimationCount++;

                if (fixAnimationCount >= maxFixAnimations) {
                    isFixing = false;
                }
            }

            gp.tileM.aggiustaFinestra(hitboxMartello);
        }

        if (keyH.upPressed && !isJumping && !isFalling && !isFixing && !isGoingDown) {
            isJumping = true;
            startY = y;
            SoundEffects.stopSound("jump");
            SoundEffects.playSound("jump");
        }

        if (isJumping) {
            y -= jumpSpeed;
            if (keyH.leftPressed) {
                direction = "left";
                x -= speed;
                isMoving = true;
            }
            if (keyH.rightPressed) {
                direction = "right";
                x += speed;
                isMoving = true;
            }
            if (startY - y >= jumpHeight) {
                isJumping = false;
                isFalling = true;
            }
        }

        if (isFalling) {
            y += fallSpeed;
            if (keyH.leftPressed) {
                direction = "left";
                x -= speed;
                isMoving = true;
            }
            if (keyH.rightPressed) {
                direction = "right";
                x += speed;
                isMoving = true;
            }
            Rectangle futureHitbox = new Rectangle(hitbox.x + speed, hitbox.y + fallSpeed, hitbox.width, hitbox.height);
            if (!ignoreCollision && collisionManager.checkTileCollision(futureHitbox)) {
                y = collisionManager.getDavanzaleYPosition(futureHitbox);
                isFalling = false;
                isJumping = false;
            }
        }

        if (!isJumping && !isFalling && !isFixing && !isChangingDirection && !isGoingDown) {
            if (keyH.leftPressed && !"left".equals(direction)) {
                isChangingDirection = true;
                changeDirectionCounter = 0;
                direction = "left";
            }
            if (keyH.rightPressed && !"right".equals(direction)) {
                isChangingDirection = true;
                changeDirectionCounter = 0;
                direction = "right";
            }
        }

        if (isChangingDirection) {
            changeDirectionCounter++;
            if (changeDirectionCounter >= changeDirectionDuration) {
                isChangingDirection = false;
            }
        }

        if (keyH.downPressed && !isFixing && !isJumping && !isFalling && !isGoingDown) {
            isGoingDown = true;
            ignoreCollision = true;
            ignoreCollisionCounter = 0;
            SoundEffects.playSound("jumpdown");
        }

        if (isGoingDown) {
            y += fallSpeed;
            if (keyH.leftPressed) {
                direction = "left";
                x -= speed;
            }
            if (keyH.rightPressed) {
                direction = "right";
                x += speed;
            }
            ignoreCollisionCounter++;
            if (ignoreCollisionCounter >= ignoreCollisionDuration) {
                isGoingDown = false;
                ignoreCollision = false;
            }
        }

        if (!isJumping && !isFixing && !isChangingDirection && !isGoingDown) {
            if (keyH.leftPressed || keyH.rightPressed) {
                frameCounter++;
                if (frameCounter >= animationSpeed) {
                    animationFrame = (animationFrame + 1) % 4;
                    frameCounter = 0;
                }

                if (keyH.leftPressed) {
                    direction = "left";
                    x -= speed;
                    isMoving = true;
                }
                if (keyH.rightPressed) {
                    direction = "right";
                    x += speed;
                    isMoving = true;
                }
            } else {
                animationFrame = 0;
            }
        }

        if (!isFalling && !isJumping) {
            if (!collisionManager.checkTileCollision(hitbox)) {
                isFalling = true;
                isJumping = false;
            }
        }

        if ("left".equals(direction)) {
            hitbox.x = x + offsetXLeft;
        } else if ("right".equals(direction)) {
            hitbox.x = x + offsetXRight;
        }

        if (x < 400) {
            x = 400;
        }
        if (x > gp.getWidth() - hitboxWidth - offsetXLeft - 485) {
            x = gp.getWidth() - hitboxWidth - offsetXLeft - 485;
        }

        if (y >= 764) {
            y = 764;
            isFalling = false;
            isJumping = false;
        }

        if (y < 300) {
            y = 300;
            isFalling = true;
            isJumping = false;
        }
        hitbox.y = y + 16;
    }

    public void draw(Graphics2D g) {
        BufferedImage image = null;

        // ✅ EFFETTO LAMPEGGIO DURANTE IL POTENZIAMENTO
        if (isPoweredUp && !powerUpVisible) {
            if (isFelixHead3Visible) {
                g.drawImage(felixHead1, 400, -20, 80, 90, null);
            }
            if (isFelixHead2Visible) {
                g.drawImage(felixHead2, 430, -20, 80, 90, null);
            }
            if (isFelixHead1Visible) {
                g.drawImage(felixHead3, 460, -20, 80, 90, null);
            }
            return;
        }

        if (!finalDeath && (System.currentTimeMillis() - deathTimeStart) < IMMUNITY_TIME) {
            if (System.currentTimeMillis() - lastBlinkTime >= 300) {
                felixVisible = !felixVisible;
                lastBlinkTime = System.currentTimeMillis();
            }
            if (!felixVisible) {
                return;
            }
        }

        // ✅ ANIMAZIONE MORTE FINALE (priorità massima)
        if (finalDeath && felixFinalDeath) {
            image = finalDeathSprites[finalDeathAnimationFrame];
            int scale = 2;
            int scaledWidth = image.getWidth() * scale;
            int scaledHeight = image.getHeight() * scale;
            g.drawImage(image, x, y, scaledWidth, scaledHeight, null);
            
            // Disegna le teste anche durante la morte finale
            if (isFelixHead3Visible) {
                g.drawImage(felixHead1, 400, -20, 80, 90, null);
            }
            if (isFelixHead2Visible) {
                g.drawImage(felixHead2, 430, -20, 80, 90, null);
            }
            if (isFelixHead1Visible) {
                g.drawImage(felixHead3, 460, -20, 80, 90, null);
            }
            return;
        }

        if (isFelixHead3Visible) {
            g.drawImage(felixHead1, 400, -20, 80, 90, null);
        }
        if (isFelixHead2Visible) {
            g.drawImage(felixHead2, 430, -20, 80, 90, null);
        }
        if (isFelixHead1Visible) {
            g.drawImage(felixHead3, 460, -20, 80, 90, null);
        }

        // ✅ ANIMAZIONE MANGIARE TORTA
        if (isEating) {
            if ("left".equals(direction)) {
                image = eatingLeft[eatingAnimationFrame];
            } else {
                image = eatingRight[eatingAnimationFrame];
            }
        }
        else if (isDead) {
            BufferedImage deathImage = null;
            if ("right".equals(direction)) {
                if (deathAnimationFrame == 0) {
                    deathImage = death1;
                } else if (deathAnimationFrame == 1) {
                    deathImage = death3;
                } else if (deathAnimationFrame == 2) {
                    deathImage = death1;
                } else if (deathAnimationFrame == 3) {
                    deathImage = death3;
                }
            }
            if ("left".equals(direction)) {
                if (deathAnimationFrame == 0) {
                    deathImage = death2;
                } else if (deathAnimationFrame == 1) {
                    deathImage = death4;
                } else if (deathAnimationFrame == 2) {
                    deathImage = death2;
                } else if (deathAnimationFrame == 3) {
                    deathImage = death4;
                }
            }

            g.drawImage(deathImage, x, y, deathImage.getWidth() * 2, deathImage.getHeight() * 2, null);
            return;
        } else if (isFixing) {
            if ("left".equals(direction)) {
                if (fixAnimationCount % 2 == 0) {
                    image = left1;
                } else {
                    image = fixL;
                }
            } else if ("right".equals(direction)) {
                if (fixAnimationCount % 2 == 0) {
                    image = right1;
                } else {
                    image = fixR;
                }
            }
        } else if (isChangingDirection) {
            if ("left".equals(direction)) {
                image = changeDirectionL;
            } else if ("right".equals(direction)) {
                image = changeDirectionR;
            }
        } else if (isJumping || isFalling) {
            if ("left".equals(direction)) {
                image = jumpL;
            } else if ("right".equals(direction)) {
                image = jumpR;
            }
        } else if (isGoingDown) {
            if ("left".equals(direction)) {
                image = goingDownL;
            } else if ("right".equals(direction)) {
                image = goingDownR;
            }
        } else if (isMoving) {
            switch (direction) {
                case "left":
                    if (animationFrame == 0) {
                        image = left1;
                    } else if (animationFrame == 1) {
                        image = left2;
                    } else if (animationFrame == 2) {
                        image = left3;
                    } else if (animationFrame == 3) {
                        image = left2;
                    }
                    break;
                case "right":
                    if (animationFrame == 0) {
                        image = right1;
                    } else if (animationFrame == 1) {
                        image = right2;
                    } else if (animationFrame == 2) {
                        image = right3;
                    } else if (animationFrame == 3) {
                        image = right2;
                    }
                    break;
            }
        } else {
            if ("left".equals(direction)) {
                image = steadyL;
            } else if ("right".equals(direction)) {
                image = steadyR;
            }
        }

        int scale = 2;
        int scaledWidth = image.getWidth() * scale;
        int scaledHeight = image.getHeight() * scale;

        g.drawImage(image, x, y, scaledWidth, scaledHeight, null);
    }

    public void setActive(boolean active) {
        this.isActive = active;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public Rectangle getHitboxMartello() {
        return hitboxMartello;
    }

    public void startEatingAnimation() {
        if (!isEating) {
            isEating = true;
            eatingAnimationFrame = 0;
            eatingAnimationCounter = 0;
            System.out.println("Felix inizia a mangiare la torta!");
        }
    }

    public boolean isEating() {
        return isEating;
    }

    public boolean isPoweredUp() {
        return isPoweredUp;
    }

    public boolean isFinalDeathAnimationComplete() {
        return finalDeathAnimationComplete;
    }

    public void handleCollisionWithBrick(Brick brick) {
        if (felixFinalDeath) {
            return;
        }

        if (isPoweredUp) {
            System.out.println("Felix è invulnerabile! Mattone ignorato.");
            return;
        }

        if (!isDead && (System.currentTimeMillis() - deathTimeStart) >= IMMUNITY_TIME) {
            isDead = true;
            deathAnimationFrame = 0;
            deathAnimationCounter = 0;
            deathTimeStart = System.currentTimeMillis();
            felixHealth--;

            SoundEffects.playSound("die0");

            if (felixHealth == 3) {
                isFelixHead3Visible = false;
            } else if (felixHealth == 2) {
                isFelixHead2Visible = false;
            } else if (felixHealth == 1) {
                isFelixHead1Visible = false;
                finalDeath = true;
                felixFinalDeath = true;
                finalDeathAnimationFrame = 0;
                finalDeathAnimationCounter = 0;
                SoundEffects.playSound("die1");
                return;
            }

            lastBlinkTime = System.currentTimeMillis();
            System.out.println("Felix entra nella sequenza di morte.");
        }
    }

    public void stopAndClear() {
        isActive = false;
    }
}