import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;

class CraneManager {
    private Image[] craneLeftFrames = new Image[2];
    private Image[] craneRightFrames = new Image[2];
    private int craneLeftX = 530;
    private int craneRightX = 610;
    
    // ✅ TIMING OTTIMIZZATO: Le gru si muovono più lentamente
    // Velocità originale con Timer(33ms) implicava ~30 updates/sec
    // Manteniamo la stessa velocità relativa
    private static final int CRANE_SPEED = 5;
    private static final int FRAME_DELAY = 5; // Cambia sprite ogni 5 frames
    private static final int WAIT_TIME = 140; // Frames di attesa iniziale
    
    private int frameCounterLeft = 0;
    private int frameCounterRight = 0;
    private int currentFrameLeft = 0;
    private int currentFrameRight = 0;
    private int waitCounter = 0;
    private boolean moving = false;

    public CraneManager() {
        loadCraneImages();
    }

    private void loadCraneImages() {
        try {
            craneLeftFrames[0] = ImageIO.read(getClass().getResourceAsStream("/map/gruSx.png"));
            craneLeftFrames[1] = ImageIO.read(getClass().getResourceAsStream("/map/gruSx1.png"));
            craneRightFrames[0] = ImageIO.read(getClass().getResourceAsStream("/map/gruDx.png"));
            craneRightFrames[1] = ImageIO.read(getClass().getResourceAsStream("/map/gruDx1.png"));
            System.out.println("CraneManager: Immagini gru caricate");
        } catch (IOException e) {
            System.err.println("CraneManager: Errore caricamento immagini");
            e.printStackTrace();
        }
    }

    public void update() {
        if (!moving) {
            waitCounter++;
            if (waitCounter >= WAIT_TIME) {
                moving = true;
                waitCounter = 0;
            }
            return;
        }
        
        // Aggiornamento frame separato per le due gru
        frameCounterLeft++;
        frameCounterRight++;

        if (frameCounterLeft >= FRAME_DELAY) {
            frameCounterLeft = 0;
            currentFrameLeft = (currentFrameLeft + 1) % 2;
        }

        if (frameCounterRight >= FRAME_DELAY) {
            frameCounterRight = 0;
            currentFrameRight = (currentFrameRight + 1) % 2;
        }

        // Movimento delle gru
        if (craneLeftX > -500) {
            craneLeftX -= CRANE_SPEED;
        }
        if (craneRightX < 1600) {
            craneRightX += CRANE_SPEED;
        }
    }

    public void draw(Graphics2D g2) {
        if (craneLeftFrames[currentFrameLeft] != null && craneRightFrames[currentFrameRight] != null) {
            g2.drawImage(craneLeftFrames[currentFrameLeft], craneLeftX, 350, 328, 496, null);
            g2.drawImage(craneRightFrames[currentFrameRight], craneRightX, 350, 328, 496, null);
            g2.drawImage(craneLeftFrames[currentFrameLeft], craneLeftX - 132, 350, 328, 496, null);
            g2.drawImage(craneRightFrames[currentFrameRight], craneRightX + 132, 350, 328, 496, null);
        }
    }
}