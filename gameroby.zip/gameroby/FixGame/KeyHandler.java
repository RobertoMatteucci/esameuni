


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {

    public boolean upPressed, downPressed, leftPressed, rightPressed, spacePressed, enterPressed;
    private boolean restartPressed; // Variabile per il tasto di restart

    @Override
    public void keyTyped(KeyEvent e){

    }

    @Override
    public void keyPressed(KeyEvent e){
        
        int code = e.getKeyCode();

        if(code == KeyEvent.VK_UP) { // if user pressed the letter then...

            upPressed = true;

        }
        if(code == KeyEvent.VK_LEFT) { // if user pressed the letter then...

            leftPressed = true;

        }
        if(code == KeyEvent.VK_DOWN) { // if user pressed the letter then...

            downPressed = true;

        }
        if(code == KeyEvent.VK_RIGHT) { // if user pressed the letter then...

            rightPressed = true;

        }
        if(code == KeyEvent.VK_SPACE) { // if user pressed the letter then...

            spacePressed = true;

        }
        if(code == KeyEvent.VK_ENTER) {

            enterPressed = true;

        }
        // Se preme ESC, esce dal gioco
        if (code == KeyEvent.VK_ESCAPE) {
            System.exit(0); // Chiude l'applicazione
        }
    }
    /*questa porzione di codice serve affinchè se non pigio nulla, il mio personaggio sta fermo */
    @Override
    public void keyReleased(KeyEvent e){
        
        int code = e.getKeyCode();

        if(code == KeyEvent.VK_UP) { 

            upPressed = false;

        }
        if(code == KeyEvent.VK_LEFT) { 

            leftPressed = false;

        }
        if(code == KeyEvent.VK_DOWN) { 

            downPressed = false;

        }
        if(code == KeyEvent.VK_RIGHT) { 

            rightPressed = false;

        }
        if(code == KeyEvent.VK_SPACE) { 

            spacePressed = false;

        }
        if(code == KeyEvent.VK_ENTER) {

            enterPressed = false;

        }
        if (code == KeyEvent.VK_SPACE) {
            restartPressed = false;
        }
    }
    public boolean userPressedRestartButton() {
        return restartPressed;
    }  
}





