import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Brick {
    private int x, y;
    private int width = 20;
    private int height = 10;
    private int speed = 4;  // ✅ Velocità sincronizzata con animazione Ralph
    private Image image;
    private Rectangle brickHitbox;
    
    // ✅ Carica l'immagine solo una volta (static)
    private static Image brickImage = null;
    
    static {
        try {
            brickImage = ImageIO.read(Brick.class.getResourceAsStream("/map/brick.png"));
            System.out.println("Brick: Immagine caricata con successo");
        } catch (IOException e) {
            System.err.println("Brick: Errore caricamento immagine");
            e.printStackTrace();
        }
    }

    public Brick(int x, int y) {
        this.x = x;
        this.y = y;
        this.image = brickImage; // Usa l'immagine condivisa
        this.brickHitbox = new Rectangle(x, y, width, height);
    }

    public void update() {
        y += speed;
        brickHitbox.setBounds(x, y, width, height + 20);
    }

    public void draw(Graphics g) {
        if (image != null) {
            g.drawImage(image, x, y, null);
        }
        
        // ✅ DEBUG: Disegna hitbox solo se necessario
        // Commenta questa riga in produzione per migliori performance
        // g.setColor(Color.RED);
        // g.drawRect(brickHitbox.x + 15, brickHitbox.y + 18, brickHitbox.width + 3, brickHitbox.height + 3);
    }

    public boolean isOutOfScreen() {
        return y > 850; // ✅ Margine extra per essere sicuri
    }

    public Rectangle brickGetHitbox() {
        return brickHitbox;
    }
}