import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.*;

class Menu extends JFrame {
    private ImageIcon sfondo = new ImageIcon(getClass().getResource("/intro/Menu.png"));
    private BufferedImage[] digitImages = new BufferedImage[10];
    private int record = 0;

    public static final int START = 1;
    public static final int EXIT = 2;
    private volatile int scelta = 0;

    private CardLayout cardLayout;
    private JPanel mainPanel;

    public Menu() {
        SoundEffects.loadSound("intro1", "snd/intro1.wav");
        SoundEffects.playSoundLoop("intro1");

        loadDigitImages();
        record = HighScoreManager.loadHighScore();

        setTitle("Fix-it FELIX - Menu");
        setSize(600, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // CardLayout e pannello principale
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // ===========================
        // 🟦 PANNELLO MENU PRINCIPALE
        // ===========================
        JPanel menuPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(sfondo.getImage(), 0, -50, getWidth(), getHeight(), this);

                // Disegna il record con le cifre
                Graphics2D g2 = (Graphics2D) g;
                String scoreString = String.format("%06d", record);
                int startX = 230;
                int y = 470;

                for (int i = 0; i < scoreString.length(); i++) {
                    int digit = Character.getNumericValue(scoreString.charAt(i));
                    if (digitImages[digit] != null) {
                        g2.drawImage(digitImages[digit], startX + i * 40, y, 30, 45, null);
                    }
                }
            }
        };
        menuPanel.setBackground(Color.BLACK);
        menuPanel.setLayout(null);

        // Etichetta "Record"
        ImageIcon recordIcon = new ImageIcon(getClass().getResource("/intro/Record.png"));
        ImageIcon scaledRecordIcon = scaleImage(recordIcon, 250, 200);
        JLabel recordLabel = new JLabel(scaledRecordIcon);
        recordLabel.setBounds(20, 450, 200, 90);
        menuPanel.add(recordLabel);

        // Bottoni del menu principale
        JButton startButton = createButton("/intro/JBStartGame.png", "/intro/JBStartGame_Hover.png", START);
        JButton instructionsButton = createButton("/intro/JBInfo.png", "/intro/JBInfo_Hover.png", 0);
        JButton exitButton = createButton("/intro/JBQuitGame.png", "/intro/JBQuitGame_Hover.png", EXIT);

        startButton.setBounds(60, 550, 170, 50);
        instructionsButton.setBounds(200, 630, 150, 50);
        exitButton.setBounds(300, 550, 170, 50);

        menuPanel.add(startButton);
        menuPanel.add(instructionsButton);
        menuPanel.add(exitButton);

        // ========================
        // 📘 PANNELLO ISTRUZIONI
        // ========================
        JPanel instructionsPanel = new JPanel(null);
        instructionsPanel.setBackground(Color.BLACK);

        // Sfondo istruzioni
        ImageIcon backgroundIcon = new ImageIcon(getClass().getResource("/intro/Scenary1.png"));
        JLabel backgroundLabel = new JLabel(scaleImage(backgroundIcon, 600, 450));
        backgroundLabel.setBounds(0, 113, 600, 450);

        // Immagini istruzioni
        ImageIcon instr1 = new ImageIcon(getClass().getResource("/intro/Instruction1.png"));
        JLabel imageLabel1 = new JLabel(scaleImage(instr1, 120, 100));
        imageLabel1.setBounds(10, 0, 110, 110);

        ImageIcon instr2 = new ImageIcon(getClass().getResource("/intro/Instruction2.png"));
        JLabel imageLabel2 = new JLabel(scaleImage(instr2, 100, 100));
        imageLabel2.setBounds(150, 58, 100, 39);

        // Testo istruzioni
        JLabel label1 = new JLabel("<html>Utilizza le frecce per spostarti,<br>la barra spaziatrice per aggiustare le finestre.</html>");
        label1.setFont(new Font("Monospaced", Font.BOLD, 14));
        label1.setForeground(Color.WHITE);
        label1.setBounds(290, 35, 300, 60);

        // Bottone "Indietro"
        ImageIcon backIcon = scaleImage(new ImageIcon(getClass().getResource("/intro/JBack.png")), 170, 50);
        ImageIcon backHoverIcon = scaleImage(new ImageIcon(getClass().getResource("/intro/JBack_Hover.png")), 170, 50);

        JButton backButton = new JButton(backIcon);
        backButton.setRolloverIcon(backHoverIcon);
        backButton.setBounds(200, 600, 170, 50);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "menu"));

        // Aggiungi componenti al pannello istruzioni
        instructionsPanel.add(backgroundLabel);
        instructionsPanel.add(imageLabel1);
        instructionsPanel.add(imageLabel2);
        instructionsPanel.add(label1);
        instructionsPanel.add(backButton);

        // Sposta lo sfondo in fondo alla pila
        instructionsPanel.setComponentZOrder(backgroundLabel, instructionsPanel.getComponentCount() - 1);

        // Collega il bottone istruzioni al cambio pannello
        instructionsButton.addActionListener(e -> cardLayout.show(mainPanel, "instructions"));

        // Aggiungi entrambi i pannelli al contenitore principale
        mainPanel.add(menuPanel, "menu");
        mainPanel.add(instructionsPanel, "instructions");

        // Mostra inizialmente il menu principale
        cardLayout.show(mainPanel, "menu");
        add(mainPanel);
        setVisible(true);
    }

    private void loadDigitImages() {
        for (int i = 0; i < 10; i++) {
            try {
                String path = "/map/digits" + i + ".png";
                var stream = getClass().getResourceAsStream(path);
                if (stream == null) {
                    System.err.println("❌ Immagine non trovata: " + path);
                    continue;
                }
                digitImages[i] = ImageIO.read(stream);
                System.out.println("✅ Cifra caricata: " + path);
            } catch (Exception e) {
                System.err.println("❌ Errore nel caricare cifra " + i);
                e.printStackTrace();
            }
        }
    }

    private JButton createButton(String iconPath, String hoverPath, int action) {
        JButton button = new JButton(new ImageIcon(getClass().getResource(iconPath)));
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setRolloverIcon(new ImageIcon(getClass().getResource(hoverPath)));
        button.addActionListener(e -> {
            if (action != 0) {
                handleSelection(action);
            }
        });
        return button;
    }

    private synchronized void handleSelection(int action) {
        scelta = action;
        SoundEffects.stopSound("intro1");
        dispose();
        notifyAll();
    }

    public synchronized int waitForMenuResponse() {
        while (scelta == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return scelta;
    }

    private ImageIcon scaleImage(ImageIcon icon, int width, int height) {
        Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
}