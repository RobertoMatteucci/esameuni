import java.awt.Rectangle;
import java.util.ArrayList;

public class LivelloCompletato {

    private GamePanel gp;
    private LivelloN livN;
    private ArrayList<Rectangle> collisionTiles;
    private ArrayList<Rectangle> collisioneFinestre;
    private Window[] animazioneFinestre;
    private int windowWidth, windowHeight, gapX, gapY;
   

    public LivelloCompletato(GamePanel gp,
                              ArrayList<Rectangle> collisionTiles,
                              ArrayList<Rectangle> collisioneFinestre,
                              int windowWidth, int windowHeight,
                              int gapX, int gapY, LivelloN livN) {
        this.gp = gp;
        this.livN = livN;
        this.collisionTiles = collisionTiles;
        this.collisioneFinestre = collisioneFinestre;
        this.windowWidth = windowWidth;
        this.windowHeight = windowHeight;
        this.gapX = gapX;
        this.gapY = gapY;

    }

    public Window[] rebuildStage() {
        if(livN.getNumeroLivello() % 2 == 0) {
            collisionTiles.clear();
            collisioneFinestre.clear();

            // Collisioni di base
            collisionTiles.add(new Rectangle(513, 661, 440, 1));
            collisionTiles.add(new Rectangle(513, 789, 440, 1));
            collisionTiles.add(new Rectangle(513, 519, 440, 1));
            collisionTiles.add(new Rectangle(513, 394, 440, 1));

            // Finestre
            collisioneFinestre.add(new Rectangle(714, 340, windowWidth - 30, windowHeight - 65));
            collisioneFinestre.add(new Rectangle(714, 465, windowWidth - 30, windowHeight - 65));
            collisioneFinestre.add(new Rectangle(714, 612, windowWidth - 30, windowHeight - 65));
            collisioneFinestre.add(new Rectangle(714, 736, windowWidth - 30, windowHeight - 65));

            for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        int x = 520 + j * (windowWidth + gapX);
                        int y = 612 + i * (windowHeight + (gapY-1));
                        collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                    }
                    for (int j = 0; j < 2; j++) {
                        int x = 811 + j * (windowWidth + 12);
                        int y = 612 + i * (windowHeight + gapY);
                        collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                    }
                    for (int j = 0; j < 2; j++) {
                        int x = 520 + j * (windowWidth + (gapX));
                        int y = 340 + i * (windowHeight + (gapY-1));
                        collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                    }
                    for (int j = 0; j < 2; j++) {
                        int x = 811 + j * (windowWidth + 13);
                        int y = 340 + i * (windowHeight + (-3));
                        collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
        
                    }
                }

                
                animazioneFinestre = new Window[collisioneFinestre.size()];
                for (int i = 0; i < collisioneFinestre.size(); i++) {
                    animazioneFinestre[i] = new Window(collisioneFinestre.get(i).x, collisioneFinestre.get(i).y);
                    animazioneFinestre[i].getTileImage();
                }
        }
        else{
            collisionTiles.clear();
            collisioneFinestre.clear();

            collisionTiles.add(new Rectangle(513, 661, 440, 1));
            collisionTiles.add(new Rectangle(510, 789, 152, 1));
            collisionTiles.add(new Rectangle(803, 789, 152, 1));
            collisionTiles.add(new Rectangle(513, 519, 440, 1));
            collisionTiles.add(new Rectangle(513, 394, 440, 1));

            collisioneFinestre.add(new Rectangle(714, 341, windowWidth - 30, windowHeight - 65));
            collisioneFinestre.add(new Rectangle(714, 467, windowWidth - 30, windowHeight - 65));

            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    int x = 520 + j * (windowWidth + gapX);
                    int y = 609 + i * (windowHeight + gapY);
                    collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                }
                for (int j = 0; j < 2; j++) {
                    int x = 814 + j * (windowWidth + 13);
                    int y = 609 + i * (windowHeight + gapY);
                    collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                }
                for (int j = 0; j < 2; j++) {
                    int x = 520 + j * (windowWidth + gapX);
                    int y = 341 + i * (windowHeight + gapY);
                    collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                }
                for (int j = 0; j < 2; j++) {
                    int x = 811 + j * (windowWidth + 13);
                    int y = 341 + i * (windowHeight + (-2));
                    collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
                }
            }

            animazioneFinestre = new Window[collisioneFinestre.size()];
            for (int i = 0; i < collisioneFinestre.size(); i++) {
                animazioneFinestre[i] = new Window(collisioneFinestre.get(i).x, collisioneFinestre.get(i).y);
                animazioneFinestre[i].getTileImage();
            }
        }
        return animazioneFinestre;
    }
    
    public int getNumeroFinestre() {
        return collisioneFinestre.size();
    }
}
