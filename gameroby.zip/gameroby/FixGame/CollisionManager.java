import java.awt.Rectangle;

public class CollisionManager {

    public TileManager tileManager;

    public CollisionManager(TileManager tileManager) {
        this.tileManager = tileManager;
    }

    /**
     * Verifica se un rettangolo collide con i rettangoli di collisione dei tiles.
     *
     * @param hitbox Il rettangolo di collisione del giocatore.
     * @return True se c'è una collisione, altrimenti False.
     */
    public boolean checkTileCollision(Rectangle playerHitbox) {
        for (Rectangle tileHitbox : tileManager.getCollisionTiles()) {
            if (tileHitbox.intersects(playerHitbox)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Controlla la collisione tra il martello e le finestre rotte per determinare se
     * la finestra viene riparata.
     *
     * @param martelloHitbox Il rettangolo di collisione del martello.
     * @return True se il martello colpisce una finestra rotta e può essere riparata.
     */
    public boolean controllaCollisioneFinestre(Rectangle martelloHitbox) {
        
            for (int i = 0; i < tileManager.getCollisioneFinestre().size(); i++) {
                Rectangle tileHitbox = tileManager.getCollisioneFinestre().get(i);
                if (tileHitbox.intersects(martelloHitbox)) {
                    // Verifica se la finestra è rotta e può essere riparata
                    if (martelloHitbox.intersects(tileHitbox)) {
                        // Invoca il metodo nel TileManager per aggiustare la finestra
                        tileManager.aggiustaFinestra(martelloHitbox); // Passa un Graphics2D per il disegno
                        return true;
                    }
                }
            }
    
        return false;
    }

    public int getDavanzaleYPosition(Rectangle playerHitbox) {
        for (Rectangle tileHitbox : tileManager.getCollisionTiles()) {
            if (tileHitbox.intersects(playerHitbox)) {
                return tileHitbox.y - playerHitbox.height - 6;  // Allinea il player al davanzale
            }
        }
        return playerHitbox.y;  // Nessuna collisione, ritorna la posizione attuale
    }
}
