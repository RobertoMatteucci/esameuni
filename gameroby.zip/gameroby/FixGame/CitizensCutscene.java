import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class CitizensCutscene {
    
    private GamePanel gp;
    
    // Sprite degli abitanti
    private BufferedImage citizen1, citizen2, citizen3, citizen4;
    private BufferedImage speechBubble;
    
    // ✅ Coordinate delle finestre (prese da TileManager)
    // Usiamo le stesse posizioni delle finestre del gioco
    private static final int[][] WINDOW_POSITIONS = {
        {714, 341},  // Finestra 1 (centro-alto)
        {714, 467},  // Finestra 2 (centro-basso)
        {520, 609},  // Finestra 3 (sinistra-basso)
        {595, 609},  // Finestra 4 (destra-basso)
        {814, 609},  // Finestra 5 (destra-basso)
        {903, 609},  // Finestra 6 (destra-basso)
        {520, 341},  // Finestra 7 (sinistra-alto)
        {595, 341},  // Finestra 8 (destra-alto)
        {811, 341},  // Finestra 9 (destra-alto)
        {900, 341}   // Finestra 10 (destra-alto)
    };
    
    // ✅ Dimensioni sprite
    private static final int SPRITE_SCALE = 2;
    
    // Dimensioni nuvoletta
    private static final int BUBBLE_WIDTH = 400;
    private static final int BUBBLE_HEIGHT = 84;
    
    // Stati della cutscene
    private int frameCounter = 0;
    private boolean finished = false;
    
    // ✅ Tempistiche (in frame a 30 FPS)
    private static final int CITIZENS_APPEAR = 30;  // 1 secondo - appaiono tutti insieme
    private static final int CUTSCENE_END = 120;    // 4 secondi totali
    
    // Visibilità elementi
    private boolean citizensVisible = false;
    private boolean speechVisible = false;
    
    // Numero di abitanti disponibili
    private final int NUM_ABITANTI = 4;
    
    // ✅ Quali finestre mostrare (scegliamo 4 finestre casuali o fisse)
    private int[] selectedWindows = {0, 2, 4, 1}; // 4 finestre distribuite
    
    public CitizensCutscene(GamePanel gp) {
        this.gp = gp;
        loadSprites();
    }
    
    private void loadSprites() {
        try {
            // Carica gli sprite degli abitanti (4 diversi, uno per abitante)
            citizen1 = ImageIO.read(getClass().getResourceAsStream("/abitanti/AbitanteA.png"));
            citizen2 = ImageIO.read(getClass().getResourceAsStream("/abitanti/AbitanteB.png"));
            citizen3 = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t_2.png"));
            citizen4 = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t1_2.png"));
            
            // Carica la nuvoletta con testo "FIX IT FELIX"
            speechBubble = ImageIO.read(getClass().getResourceAsStream("/abitanti/speech_bubble.png"));

            System.out.println("CitizensCutscene: Sprite caricati con successo");
        } catch (IOException e) {
            System.err.println("CitizensCutscene: Errore nel caricamento degli sprite");
            e.printStackTrace();
        }
    }
    
    public void start() {
        reset();
        System.out.println("🎬 CitizensCutscene avviata");
    }
    
    public void reset() {
        frameCounter = 0;
        finished = false;
        citizensVisible = false;
        speechVisible = false;
    }
    
    public void update() {
        if (finished) return;
        
        frameCounter++;
        
        // Fai apparire tutti gli abitanti contemporaneamente con la nuvoletta
        if (frameCounter == CITIZENS_APPEAR) {
            citizensVisible = true;
            speechVisible = true;
            SoundEffects.playSound("voice1"); // Suono quando appaiono
        }
        
        // Termina la cutscene
        if (frameCounter >= CUTSCENE_END) {
            finished = true;
            System.out.println("✅ CitizensCutscene completata");
        }
    }
    
    public void draw(Graphics2D g2) {
        if (!citizensVisible) return;
        
        // Array degli sprite
        BufferedImage[] citizens = {citizen1, citizen2, citizen3, citizen4};
        
        // ✅ Disegna 4 abitanti alle finestre selezionate
        for (int i = 0; i < selectedWindows.length; i++) {
            int windowIndex = selectedWindows[i];
            int x = WINDOW_POSITIONS[windowIndex][0];
            int y = WINDOW_POSITIONS[windowIndex][1];
            
            // Usa uno sprite diverso per ogni finestra
            BufferedImage currentSprite = citizens[i];
            
            if (currentSprite != null) {
                // ✅ Usa lo stesso offset e scale di Pie.java
                int width = currentSprite.getWidth() * SPRITE_SCALE;
                int height = currentSprite.getHeight() * SPRITE_SCALE;
                g2.drawImage(currentSprite, x + 6, y + 23, width, height, null);
            }
        }
        
        // Disegna la nuvoletta di testo sopra le finestre centrali
        if (speechVisible && speechBubble != null) {
            // Centra la nuvoletta tra le finestre 0 e 1 (quelle centrali in alto)
            int centerX = (WINDOW_POSITIONS[0][0] + WINDOW_POSITIONS[1][0]) / 2;
            int bubbleX = centerX - BUBBLE_WIDTH / 2 + 20;
            int bubbleY = WINDOW_POSITIONS[0][1] - BUBBLE_HEIGHT - 20;
            
            g2.drawImage(speechBubble, bubbleX, bubbleY, BUBBLE_WIDTH, BUBBLE_HEIGHT, null);
        }
    }
    
    public boolean isFinished() {
        return finished;
    }
}