import java.awt.Graphics2D;
import java.awt.Image;

public class FallingObject {
    private int x, y;
    private int speed;  // Velocità di caduta dell'oggetto
    private Image image;
    private int offsetX; // Offset rispetto a Ralph
    private int offsetY; // Offset verticale rispetto a Ralph

    // Modifica del costruttore per ricevere le coordinate di Ralph
    public FallingObject(int ralphX, int ralphY, int offsetX, int offsetY, int speed, Image image) {
        this.x = ralphX + offsetX;  // Posizione orizzontale attorno a Ralph
        this.y = ralphY + offsetY;  // Posizione verticale attorno a Ralph
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.speed = speed;
        this.image = image;
    }

    // Metodo per aggiornare la posizione dell'oggetto (ogni frame)
    public void update() {
        y += speed;  // L'oggetto scende verso il basso
    }

    // Metodo per disegnare l'oggetto
    public void draw(Graphics2D g2) {
        if (image == null) return; // ✅ Controllo null-safe
        
        int width = 50;  // Imposta la larghezza desiderata
        int height = 50; // Imposta l'altezza desiderata   
    
        // Genera un offset casuale per x e y
        int randomOffsetX = (int) (Math.random() * 10 - 5); // Aggiunge un offset tra -5 e +5 a x
        int randomOffsetY = (int) (Math.random() * 10 - 5); // Aggiunge un offset tra -5 e +5 a y
    
        // Applica l'offset casuale alle coordinate
        int newX = x + randomOffsetX;
        int newY = y + randomOffsetY;
    
        // Disegna l'immagine con le coordinate modificate
        g2.drawImage(image, newX, newY, width, height, null);
    }

    // Metodo che restituisce la posizione y dell'oggetto (usato per determinare quando l'oggetto ha raggiunto il fondo)
    public int getY() {
        return y;
    }

    // Metodo che restituisce la posizione x dell'oggetto (per eventuali collisioni o altre logiche)
    public int getX() {
        return x;
    }
    
    // ✅ AGGIUNTO: Metodo per rimuovere oggetti fuori schermo (ottimizzazione)
    public boolean isOffScreen() {
        return y > 850; // Fuori dallo schermo
    }
}