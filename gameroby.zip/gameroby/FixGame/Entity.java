import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Entity {

    public int x, y;
    public int speed;

    public BufferedImage steadyR, steadyL, right1, right2, right3, left1, left2, left3, fixR, fixL, 
                          changeDirectionL, changeDirectionR, jumpL, jumpR, goingDownL, goingDownR, 
                          death1, death2, death3, death4, felixHead1, felixHead2, felixHead3;
                        
    
    // ✅ INIZIALIZZAZIONE DEGLI ARRAY PER L'ANIMAZIONE DI MANGIARE LA TORTA
    public BufferedImage[] eatingLeft = new BufferedImage[7];
    public BufferedImage[] eatingRight = new BufferedImage[7];

    public BufferedImage[] finalDeathSprites = new BufferedImage[9];

    
    public String direction;

    public int spriteCounter = 0;
    public int spriteNum = 1;
    public Rectangle solidArea; // Rettangolo per le collisioni del personaggio
    public boolean collisionOn = false;

}