import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;

public class FelixIntroCutscene {

    private Player realPlayer;
    private GamePanel gp;
    
    // --- Immagini della Cutscene ---
    private BufferedImage walk1, walk2, walk3;
    private BufferedImage walk1h, walk2h, walk3h;
    private BufferedImage grab1, grab2, grab3;
    private BufferedImage hammerImage;
    private BufferedImage currentImage;

    // --- Stato della Cutscene ---
    private enum State {
        ENTERING,
        GRABBING,
        EXITING,
        FINISHED
    }
    private State currentState;

    // --- Posizione e Animazione ---
    private int x, y;
    private final int BASE_FELIX_Y_POS;
    private int animationFrame = 0;
    private int frameCounter = 0;
    
    private final int WALK_ANIMATION_SPEED = 5;
    private final int GRAB_ANIMATION_SPEED = 15;
    
    // --- Parametri della Scena (✅ AGGIORNATI PER LO SCHERMO RIDOTTO) ---
    private final int START_X;  // Posizione X iniziale (fuori schermo destra)
    private final int HAMMER_X; // Posizione X centrale (dove si ferma)
    private final int END_X;    // Posizione X finale (fuori schermo sinistra)
    private final int WALK_SPEED = 5;

    private boolean showHammer = true;
    private Font arcadeFont;
    private final int TEXT_Y;

    public FelixIntroCutscene(Player playerToActivate, GamePanel gp) {
        this.realPlayer = playerToActivate;
        this.gp = gp;
        
        // ✅ CALCOLA LE POSIZIONI IN BASE ALL'AREA DI GIOCO
        this.TEXT_Y = 400;
        this.BASE_FELIX_Y_POS = 450;
        
        // ✅ HAMMER_X: Centro dell'area di gioco
        this.HAMMER_X = GamePanel.GAME_AREA_X + (GamePanel.GAME_AREA_WIDTH / 2) - 32; // -32 per centrare lo sprite
        
        // ✅ START_X: Fuori schermo a destra (oltre il bordo destro dell'area di gioco)
        this.START_X = GamePanel.GAME_AREA_X + GamePanel.GAME_AREA_WIDTH + 50;
        
        // ✅ END_X: Fuori schermo a sinistra (prima del bordo sinistro dell'area di gioco)
        this.END_X = GamePanel.GAME_AREA_X - 100;

        loadImages();
        loadFont();
        
        System.out.println("🎬 FelixIntroCutscene inizializzata:");
        System.out.println("   START_X: " + START_X);
        System.out.println("   HAMMER_X: " + HAMMER_X);
        System.out.println("   END_X: " + END_X);
        System.out.println("   GAME_AREA: " + GamePanel.GAME_AREA_X + " -> " + 
                          (GamePanel.GAME_AREA_X + GamePanel.GAME_AREA_WIDTH));
    }

    private void loadImages() {
        try {
            // Immagini senza martello
            walk1 = ImageIO.read(getClass().getResourceAsStream("/felix/2.png"));
            walk2 = ImageIO.read(getClass().getResourceAsStream("/felix/3.png"));
            walk3 = ImageIO.read(getClass().getResourceAsStream("/felix/4.png"));

            // Immagini CON il martello
            walk1h = ImageIO.read(getClass().getResourceAsStream("/felix/left1.png"));
            walk2h = ImageIO.read(getClass().getResourceAsStream("/felix/left2.png"));
            walk3h = ImageIO.read(getClass().getResourceAsStream("/felix/left3.png"));
            
            // Animazione "Grab"
            grab1 = ImageIO.read(getClass().getResourceAsStream("/felix/5.png"));
            grab2 = ImageIO.read(getClass().getResourceAsStream("/felix/6.png"));
            grab3 = ImageIO.read(getClass().getResourceAsStream("/felix/7.png"));

            // Martello a terra
            hammerImage = ImageIO.read(getClass().getResourceAsStream("/felix/hammer.png")); 
            
            currentImage = walk1;
            System.out.println("✅ Immagini FelixIntroCutscene caricate!");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Errore nel caricamento delle immagini della cutscene di Felix!");
        }
    }
    
    private void loadFont() {
        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(24f);
        } catch (Exception e) {
            e.printStackTrace();
            arcadeFont = new Font("Monospaced", Font.BOLD, 24);
        }
    }

    public void start() {
        currentState = State.ENTERING;
        x = START_X;
        y = BASE_FELIX_Y_POS;
        animationFrame = 0;
        frameCounter = 0;
        showHammer = true;
        currentImage = walk1;
        System.out.println("🎬 FelixIntroCutscene STARTED - Felix spawna a x=" + x);
    }

    // Animazione camminata SENZA martello
    private void updateWalkAnimation() {
        if (frameCounter >= WALK_ANIMATION_SPEED) {
            frameCounter = 0;
            animationFrame = (animationFrame + 1) % 4; 
        }
        
        if (animationFrame == 0) {
            currentImage = walk1;
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 1) {
            currentImage = walk2;
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 2) {
            currentImage = walk3;
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 3) {
            currentImage = walk2; 
            y = BASE_FELIX_Y_POS; 
        }
    }

    // Animazione camminata CON martello
    private void updateWalkHammerAnimation() {
        if (frameCounter >= WALK_ANIMATION_SPEED) {
            frameCounter = 0;
            animationFrame = (animationFrame + 1) % 4; 
        }
        
        if (animationFrame == 0) {
            currentImage = walk1h; 
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 1) {
            currentImage = walk2h; 
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 2) {
            currentImage = walk3h; 
            y = BASE_FELIX_Y_POS; 
        } else if (animationFrame == 3) {
            currentImage = walk2h; 
            y = BASE_FELIX_Y_POS; 
        }
    }

    public void update() {
        if (currentState == State.FINISHED) {
            return;
        }

        frameCounter++;

        switch (currentState) {
            case ENTERING:
                updateWalkAnimation();

                x -= WALK_SPEED;
                if (x <= HAMMER_X) {
                    x = HAMMER_X;
                    currentState = State.GRABBING;
                    animationFrame = 0;
                    frameCounter = 0;
                    showHammer = false;
                    currentImage = grab1;
                    y = BASE_FELIX_Y_POS;
                    System.out.println("🔨 Felix prende il martello a x=" + x);
                }
                break;

            case GRABBING:
                if (frameCounter >= GRAB_ANIMATION_SPEED) {
                    frameCounter = 0;
                    animationFrame++;
                    
                    if (animationFrame == 1) { 
                        currentImage = grab2;
                    } else if (animationFrame == 2) { 
                        currentImage = grab3;
                    } else if (animationFrame > 2) {
                        currentState = State.EXITING;
                        animationFrame = 0;
                        frameCounter = 0;
                        System.out.println("🚶 Felix esce con il martello");
                    }
                }
                break;
            
            case EXITING:
                updateWalkHammerAnimation();
                
                x -= WALK_SPEED;
                
                if (x <= END_X) {
                    currentState = State.FINISHED;
                    System.out.println("✅ FelixIntroCutscene FINITA - Felix a x=" + x);
                }
                break;

            case FINISHED:
                break;
        }
    }

    public void draw(Graphics2D g2) {
        // ✅ DISEGNA SFONDO NERO SU TUTTO LO SCHERMO
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        
        // ✅ CLIP REGION PER L'AREA DI GIOCO (tutto deve rimanere dentro)
        g2.setClip(GamePanel.GAME_AREA_X, GamePanel.GAME_AREA_Y, 
                   GamePanel.GAME_AREA_WIDTH, GamePanel.GAME_AREA_HEIGHT);
        
        // 1. Disegna il martello a terra (solo all'inizio)
        if (currentState == State.ENTERING && showHammer && hammerImage != null) {
            g2.drawImage(hammerImage, HAMMER_X, BASE_FELIX_Y_POS - 20, 
                        hammerImage.getWidth() * 2, hammerImage.getHeight() * 2, null); 
        }

        // 2. Disegna Felix (sempre, tranne alla fine)
        if (currentImage != null && currentState != State.FINISHED) {
            int scale = 2;
            int scaledWidth = currentImage.getWidth() * scale;
            int scaledHeight = currentImage.getHeight() * scale;
            g2.drawImage(currentImage, x, y, scaledWidth, scaledHeight, null);
        }

        // ✅ RIPRISTINA CLIP PER DISEGNARE IL TESTO CENTRATO
        g2.setClip(null);

        // 3. Disegna il testo (centrato su TUTTO lo schermo)
        if (currentState == State.GRABBING || currentState == State.EXITING) { 
            g2.setFont(arcadeFont);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            
            String text = "I CAN FIX IT!";
            
            // ✅ CENTRA IL TESTO SU TUTTO LO SCHERMO (non solo l'area di gioco)
            int textWidth = g2.getFontMetrics().stringWidth(text);
            int textX = (gp.screenWidth - textWidth) / 2; 
            
            // Ombra nera
            g2.setColor(Color.BLACK);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (dx != 0 || dy != 0) {
                        g2.drawString(text, textX + dx, TEXT_Y + dy);
                    }
                }
            }
            
            // Testo bianco
            g2.setColor(Color.WHITE);
            g2.drawString(text, textX, TEXT_Y);
        }
        
        // ✅ DISEGNA BORDO DELL'AREA DI GIOCO
        g2.setColor(new Color(40, 40, 40));
        g2.setStroke(new java.awt.BasicStroke(4));
        g2.drawRect(GamePanel.GAME_AREA_X, GamePanel.GAME_AREA_Y, 
                    GamePanel.GAME_AREA_WIDTH, GamePanel.GAME_AREA_HEIGHT);
    }

    public boolean isFinished() {
        return currentState == State.FINISHED;
    }
}