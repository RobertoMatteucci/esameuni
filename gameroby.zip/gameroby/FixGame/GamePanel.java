import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements Runnable {

    // SCREEN SETTINGS
    public int tileSize;
    public int maxScreenCol = 13;
    public int maxScreenRow = 14;
    public int screenWidth;
    public int screenHeight;
    public InputStream is;

    // ✅ AREA DI GIOCO (zona centrale dove avviene il gameplay)
    public static final int GAME_AREA_X = 360; // Inizio area di gioco (sinistra)
    public static final int GAME_AREA_WIDTH = 745; // Larghezza area di gioco
    public static final int GAME_AREA_Y = 0; // Inizio area di gioco (alto)
    public static final int GAME_AREA_HEIGHT = 848; // Altezza area di gioco

    // FPS
    int FPS = 30;

    // Game elements
    public LivelloN livelloN = new LivelloN(1);
    TileManager tileM = new TileManager(this, livelloN);
    KeyHandler keyH = new KeyHandler();
    CollisionManager collisionManager = new CollisionManager(tileM);
    Thread gameThread;

    Player player = new Player(this, keyH, collisionManager);
    DebugDrawer debugDrawer = new DebugDrawer(player, tileM.getCollisionTiles(), tileM.getCollisioneFinestre());
    Ralph ralph = new Ralph(player);
    Duck duck = new Duck(this, player, livelloN);
    CutsceneManager cutsceneManager = new CutsceneManager(this);
    ScoreManager scoreManager = new ScoreManager();
    GameOverScreen gameOverScreen = null;

    private BufferedImage backgroundImage;

    // Livello
    public boolean livelloClear = false;
    private long tempoClearInizio = 0;
    private final int DURATA_CLEAR_MS = 2000;
    
    // Game state
    private boolean isGameOver = false;
    private boolean isPlayingDeathAnimation = false;
    private int previousWindowCount = 0;

    public GamePanel() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        screenWidth = screenSize.width;
        screenHeight = screenSize.height;

        tileSize = Math.min(screenWidth / maxScreenCol, screenHeight / maxScreenRow);

        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);

        generateBackgroundImage();
    }

    public void generateBackgroundImage() {
        int width = screenWidth;
        int height = screenHeight;
        if (width == 0 || height == 0) return;

        backgroundImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = backgroundImage.createGraphics();
        tileM.draw(g2);
        g2.dispose();
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000.0 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;

        while (gameThread != null) {
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            lastTime = currentTime;

            if (delta >= 1) {
                update();
                repaint();
                delta--;
            }
        }
    }

    public void update() {
        // Check for game over state
        if (isGameOver) {
            if (gameOverScreen != null) {
                gameOverScreen.update();
                
                // Handle keyboard input for game over screen
                if (keyH.upPressed || keyH.downPressed || keyH.leftPressed || 
                    keyH.rightPressed || keyH.enterPressed) {
                    handleGameOverInput();
                }
            }
            return;
        }
        
        // ✅ GESTIONE ANIMAZIONE DI MORTE FINALE
        if (isPlayingDeathAnimation) {
            player.update();
            duck.setActive(false);
            
            if (player.isFinalDeathAnimationComplete()) {
                isPlayingDeathAnimation = false;
                isGameOver = true;
                gameOverScreen = new GameOverScreen(this, scoreManager.getScore(), player.x, player.y);
                ralph.setActive(false);
                System.out.println("🎮 Animazione morte finale completata - Passaggio a GameOver");
            }
            return;
        }
        
        // Check if player has died (final death)
        if (player.finalDeath && !isPlayingDeathAnimation && !isGameOver) {
            isPlayingDeathAnimation = true;
            player.setActive(true);
            ralph.setActive(false);
            duck.setActive(false);
            System.out.println("💀 Inizio animazione morte finale");
            return;
        }
        
        // ✅ BLOCCA TUTTO DURANTE L'ANIMAZIONE DI MANGIARE
        if (player.isEating()) {
            player.update();
            tileM.pie.update();
            duck.setActive(false);
            return;
        } else if (duck != null && !duck.isActive() && !isPlayingDeathAnimation && !isGameOver) {
            duck.setActive(true);
        }
        
        // Se c'è una cutscene attiva, aggiorna SOLO il CutsceneManager
        if (cutsceneManager.isAnyCutsceneActive()) {
            player.setActive(false);
            ralph.setActive(false);
            duck.setActive(false);
            
            cutsceneManager.update();
            return;
        }

        // Riattiva player e ralph quando non ci sono cutscene
        player.setActive(true);
        ralph.setActive(true);
        duck.setActive(true);

        // ✅ AGGIORNAMENTI NORMALI DEL GIOCO
        tileM.update();
        player.update();
        ralph.update();
        duck.update();

        // Gestione ricostruzione finestre
        if (tileM.attivaRicostruzione) {
            tileM.animazioneFinestre = tileM.livelloCompletatoManager.rebuildStage();
            tileM.count = tileM.animazioneFinestre.length;
            previousWindowCount = tileM.count;
            tileM.attivaRicostruzione = false;
            
            tileM.resetTimer();
            System.out.println("🔄 Nuovo livello iniziato - Timer e torta resettati");
            
            generateBackgroundImage();
        }

        // Controllo completamento livello
        if (!livelloClear && livelloN.isCompletato(livelloN.getFinestreDaAggiustare() - tileM.count)) {
            livelloClear = true;
            tempoClearInizio = System.currentTimeMillis();
            scoreManager.addPoints(livelloN.getNumeroLivello() * 1000);
        }

        // Avanzamento al prossimo livello
        if (livelloClear && System.currentTimeMillis() - tempoClearInizio > DURATA_CLEAR_MS) {
            livelloClear = false;
            
            if (livelloN.getNumeroLivello() % 2 == 0) {
                System.out.println("✅ Livello " + livelloN.getNumeroLivello() + " completato");
                cutsceneManager.startYouFixedItCutscene();
            }
            
            livelloN.prossimoLivello();
            tileM.count = livelloN.getFinestreDaAggiustare();
            previousWindowCount = tileM.count;
            tileM.startScroll();
            
            duck.setLevel(livelloN.getNumeroLivello());
        }
    }
    
    private void handleGameOverInput() {
        if (keyH.upPressed) {
            gameOverScreen.handleKeyPress(java.awt.event.KeyEvent.VK_UP);
            keyH.upPressed = false;
        }
        if (keyH.downPressed) {
            gameOverScreen.handleKeyPress(java.awt.event.KeyEvent.VK_DOWN);
            keyH.downPressed = false;
        }
        if (keyH.leftPressed) {
            gameOverScreen.handleKeyPress(java.awt.event.KeyEvent.VK_LEFT);
            keyH.leftPressed = false;
        }
        if (keyH.rightPressed) {
            gameOverScreen.handleKeyPress(java.awt.event.KeyEvent.VK_RIGHT);
            keyH.rightPressed = false;
        }
        if (keyH.enterPressed) {
            gameOverScreen.handleKeyPress(java.awt.event.KeyEvent.VK_ENTER);
            keyH.enterPressed = false;
            
            if (gameOverScreen.shouldRestartGame()) {
                restartGame();
            } else if (gameOverScreen.shouldQuitGame()) {
                System.exit(0);
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // ✅ DISEGNA SFONDO NERO SU TUTTO LO SCHERMO
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, screenWidth, screenHeight);

        // ✅ CREA CLIP REGION PER L'AREA DI GIOCO
        Shape oldClip = g2.getClip();
        g2.setClip(GAME_AREA_X, GAME_AREA_Y, GAME_AREA_WIDTH, GAME_AREA_HEIGHT);

        // Draw game over screen if game is over
        if (isGameOver && gameOverScreen != null) {
            gameOverScreen.draw(g2);
        }
        // ✅ DISEGNA L'ANIMAZIONE DI MORTE FINALE
        else if (isPlayingDeathAnimation) {
            tileM.draw(g2);
            ralph.draw(g2);
            duck.draw(g2);
            debugDrawer.draw(g2);
            player.draw(g2);
        }
        // Se c'è una cutscene attiva, disegna SOLO quella
        else if (cutsceneManager.isAnyCutsceneActive()) {
            cutsceneManager.draw(g2);
        }
        // Altrimenti disegna il gioco normale
        else {
            tileM.draw(g2);
            ralph.draw(g2);
            duck.draw(g2);
            debugDrawer.draw(g2);
            player.draw(g2);

            if (livelloClear) {
                drawLevelClear(g2);
            }
        }

        // ✅ RIPRISTINA CLIP ORIGINALE
        g2.setClip(oldClip);

        // ✅ DISEGNA BORDI DELL'AREA DI GIOCO
        g2.setColor(new Color(40, 40, 40)); // Grigio scuro
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(GAME_AREA_X, GAME_AREA_Y, GAME_AREA_WIDTH, GAME_AREA_HEIGHT);

        // ✅ DISEGNA UI FUORI DALL'AREA DI GIOCO (senza clip)
        scoreManager.draw(g2, 30, 50);
        tileM.drawTimer(g2); // ✅ Timer sempre visibile, sotto lo score

        g2.dispose();
    }

    private void drawLevelClear(Graphics2D g2) {
        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            Font arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(36f);
            g2.setFont(arcadeFont);
        } catch (Exception e) {
            g2.setFont(new Font("Monospaced", Font.BOLD, 60));
        }
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);

        String text = "LEVEL " + livelloN.getNumeroLivello() + " CLEAR";
        int x = 480;
        int y = 400;

        g2.setColor(Color.BLACK);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx != 0 || dy != 0) {
                    g2.drawString(text, x + dx, y + dy);
                }
            }
        }

        g2.setColor(Color.YELLOW);
        g2.drawString(text, x, y);
    }
    
    private void restartGame() {
        // Reset game state
        isGameOver = false;
        isPlayingDeathAnimation = false;
        gameOverScreen = null;
        
        // Reset score
        scoreManager.reset();
        
        // Reset level
        livelloN = new LivelloN(1);
        livelloClear = false;
        tempoClearInizio = 0;
        previousWindowCount = 0;
        
        // Cleanup
        if (ralph != null) {
            ralph.cleanup();
        }
        if (cutsceneManager != null) {
            cutsceneManager.cleanup();
        }
        if (duck != null) {
            duck.cleanup();
        }
        
        // Reset tile manager
        tileM = new TileManager(this, livelloN);
        collisionManager = new CollisionManager(tileM);
        
        // Reset player
        player = new Player(this, keyH, collisionManager);
        
        // Reset ralph
        ralph = new Ralph(player);
        
        // Reset duck system
        duck = new Duck(this, player, livelloN);
        
        // Reset cutscene manager
        cutsceneManager = new CutsceneManager(this);
        
        // Reset debug drawer
        debugDrawer = new DebugDrawer(player, tileM.getCollisionTiles(), tileM.getCollisioneFinestre());
        
        // Regenerate background
        generateBackgroundImage();
        
        System.out.println("🎮 Game restarted!");
    }
}