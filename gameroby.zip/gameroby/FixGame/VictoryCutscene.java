import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class VictoryCutscene {
    
    // Immagini
    private BufferedImage background;
    private BufferedImage backgroundBase;
    private BufferedImage felixStanding;
    private BufferedImage felixStandingMedal;
    private BufferedImage ralphStanding;
    private BufferedImage ralphOriz;
    private BufferedImage ralphFalling1;
    private BufferedImage ralphFalling2;
    private BufferedImage ralphFalling3;
    private BufferedImage ralphFalling4;
    private BufferedImage ralphLanding1;
    private BufferedImage ralphLanding2;
    private BufferedImage ralphLanding3;
    private BufferedImage ralphMoveLeft0;
    private BufferedImage ralphMoveLeft1;
    private BufferedImage ralphBack1;
    private BufferedImage ralphBack2;
    private BufferedImage ralphStanding2;
    private BufferedImage medalImage1;
    private BufferedImage medalImage2;
    private BufferedImage medalImage3;
    private BufferedImage[] peopleImagesHappy;
    private BufferedImage[] peopleImagesAngry;
    
    // Posizioni e animazioni
    private int felixX, felixY;
    private int ralphX, ralphY;
    private int ralphInitialY;
    private int ralphLaunchStartX, ralphLaunchStartY;
    private float ralphVelocityX;
    private float ralphVelocityY;
    private int backgroundY;
    private float medalX, medalY;
    private float medalTargetY;
    private float ralphFallSpeed;
    private boolean ralphFalling;
    private int ralphSpriteIndex;
    private int ralphLandingSpriteIndex;
    private long lastSpriteChange;
    
    // ✅ CAMERA SCROLL ORIZZONTALE
    private float cameraX; // Offset orizzontale della camera
    private boolean cameraFollowingRalph;
    private float targetCameraX;
    private boolean cameraReturning; // ✅ Flag per il ritorno della camera
    
    // Posizioni degli abitanti
    private int[] peopleX;
    private int[] peopleY;
    private int[] peopleBaseY;
    private int[] peopleFirstTargetX;
    private int[] peopleSecondTargetX;
    private int[] peopleThirdTargetX;
    private boolean[] peopleStarted;
    private boolean[] peopleReachedFirstTarget;
    private boolean[] peopleReachedSecondTarget;
    private boolean peopleMoving;
    private long lastPeopleJump;
    private boolean peopleJumpUp;
    
    // Fasi della cutscene
    private int phase;
    private long phaseStartTime;
    private boolean completed;
    private boolean active;
    
    // Costanti - FASI
    private static final int PHASE_INITIAL = 0;
    private static final int PHASE_MEDAL_DESCENDS = 1;
    private static final int PHASE_MEDAL_AT_NECK = 2;
    private static final int PHASE_PEOPLE_ARRIVE_FIRST = 3;
    private static final int PHASE_PEOPLE_CELEBRATE = 4;
    private static final int PHASE_PEOPLE_GET_ANGRY = 5;
    private static final int PHASE_PEOPLE_MOVE_TO_RALPH = 6;
    private static final int PHASE_PEOPLE_LIFT_RALPH = 7;
    private static final int PHASE_PEOPLE_MOVE_TO_EDGE = 8;
    private static final int PHASE_RALPH_PARABOLIC_LAUNCH = 9;
    private static final int PHASE_RALPH_FALLS = 10;
    private static final int PHASE_SWITCH_TO_BASE = 11;
    private static final int PHASE_RALPH_LANDING = 12;
    private static final int PHASE_RALPH_COMING_BACK = 13; 
    private static final int PHASE_END = 14;
    
    // Costanti - DURATE
    private static final long INITIAL_DURATION = 2500;
    private static final long MEDAL_DESCENDS_DURATION = 800;
    private static final long MEDAL_AT_NECK_DURATION = 1500;
    private static final long PEOPLE_ARRIVE_FIRST_DURATION = 4000;
    private static final long PEOPLE_CELEBRATE_DURATION = 2000;
    private static final long PEOPLE_ANGRY_DURATION = 1000;
    private static final long PEOPLE_MOVE_TO_RALPH_DURATION = 2500;
    private static final long PEOPLE_LIFT_RALPH_DURATION = 1000;
    private static final long PEOPLE_MOVE_TO_EDGE_DURATION = 3000;
    private static final long RALPH_PARABOLIC_LAUNCH_DURATION = 1500;
    private static final long RALPH_LANDING_DURATION = 2000; 
    private static final long RALPH_COMING_BACK = 5500;
    private static final long LAST_PHASE_TIME = 2000;

    
    private static final float MEDAL_SIZE = 96;
    private static final int JUMP_HEIGHT = 8;
    private static final float MEDAL_DESCENT_SPEED = 4;
    private static final int RALPH_ORIZ_Y_OFFSET = 20;
    private static final float GRAVITY = 0.8f;
    private static final float LAUNCH_VELOCITY_X = 8f;
    private static final float LAUNCH_VELOCITY_Y = -12f;
    private static final float CONSTANT_FALL_SPEED = 15f;
    private static final int RALPH_GROUND_Y = 665;
    
    // ✅ COSTANTI CAMERA
    private static final float CAMERA_SMOOTH_FACTOR = 0.08f; // Scroll fluido
    private static final int CAMERA_RIGHT_EDGE = 850; // Quando Ralph supera questa X, la camera lo segue
    
    private int screenWidth;
    private int screenHeight;
    
    public VictoryCutscene() {
        loadImages();
        reset();
    }
    
    private void loadImages() {
        try {
            background = ImageIO.read(getClass().getResourceAsStream("/map/PalazzoCompleto.png"));
            backgroundBase = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo3.png"));
            
            felixStanding = ImageIO.read(getClass().getResourceAsStream("/felix/Static1.png"));
            felixStandingMedal = ImageIO.read(getClass().getResourceAsStream("/felix/Victory.png"));
            
            ralphStanding = ImageIO.read(getClass().getResourceAsStream("/ralph/Final1.png"));
            ralphOriz = ImageIO.read(getClass().getResourceAsStream("/ralph/Final2.png"));
            ralphFalling1 = ImageIO.read(getClass().getResourceAsStream("/ralph/Final3.png"));
            ralphFalling2 = ImageIO.read(getClass().getResourceAsStream("/ralph/Final4.png"));
            ralphFalling3 = ImageIO.read(getClass().getResourceAsStream("/ralph/Final5.png"));
            ralphFalling4 = ImageIO.read(getClass().getResourceAsStream("/ralph/Final6.png"));
            
            ralphLanding1 = ImageIO.read(getClass().getResourceAsStream("/ralph/Mud1.png"));
            ralphLanding2 = ImageIO.read(getClass().getResourceAsStream("/ralph/Mud2.png"));
            ralphLanding3 = ImageIO.read(getClass().getResourceAsStream("/ralph/Mud3.png"));

            ralphMoveLeft0 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphMoveLeft0.png"));
            ralphMoveLeft1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphMoveLeft1.png"));

            ralphBack1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack1.png"));
            ralphBack2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack2.png"));

            ralphStanding2 = ImageIO.read(getClass().getResourceAsStream("/ralph/Move9.png"));
            
            medalImage1 = ImageIO.read(getClass().getResourceAsStream("/felix/medaglia1.png"));
            medalImage2 = ImageIO.read(getClass().getResourceAsStream("/felix/medaglia2.png"));
            medalImage3 = ImageIO.read(getClass().getResourceAsStream("/felix/medaglia3.png"));
            
            peopleImagesHappy = new BufferedImage[4];
            for (int i = 0; i < peopleImagesHappy.length; i++) {
                peopleImagesHappy[i] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante" + (i+1) + "_f.png"));
            }
            
            peopleImagesAngry = new BufferedImage[4];
            for (int i = 0; i < peopleImagesAngry.length; i++) {
                peopleImagesAngry[i] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante" + (i+1) + ".png"));
            }
            
        } catch (IOException e) {
            System.err.println("Errore nel caricamento delle immagini della victory cutscene");
            e.printStackTrace();
        }
    }
    
    private void reset() {
        phase = PHASE_INITIAL;
        completed = false;
        active = false;
        ralphFalling = false;
        peopleMoving = false;
        ralphSpriteIndex = 0;
        ralphLandingSpriteIndex = 0;
        lastSpriteChange = 0;
        lastPeopleJump = 0;
        peopleJumpUp = true;
        
        // ✅ RESET CAMERA
        cameraX = 0;
        targetCameraX = 0;
        cameraFollowingRalph = false;
        cameraReturning = false;
        
        felixX = 550;
        felixY = 435;
        ralphX = 750;
        ralphY = 345;
        ralphInitialY = ralphY;
        
        backgroundY = 0;
        
        medalX = felixX + 8;
        medalY = felixY - 200;
        medalTargetY = felixY - 20;
        
        ralphFallSpeed = 0;
        ralphVelocityX = 0;
        ralphVelocityY = 0;
        
        int doorX = 486;
        peopleX = new int[]{doorX, doorX, doorX, doorX};
        peopleBaseY = new int[]{490, 490, 490, 490};
        peopleY = new int[]{490, 490, 490, 490};
        
        peopleFirstTargetX = new int[]{726, 690, 650, 615};
        peopleSecondTargetX = new int[]{906, 870, 830, 800};
        peopleThirdTargetX = new int[]{ralphX + 190, ralphX + 160, ralphX + 128, ralphX + 100};
        
        peopleStarted = new boolean[]{false, false, false, false};
        peopleReachedFirstTarget = new boolean[]{false, false, false, false};
        peopleReachedSecondTarget = new boolean[]{false, false, false, false};
    }
    
    public void start() {
        reset();
        active = true;
        phaseStartTime = System.currentTimeMillis();
    }
    
    public void update() {
        if (!active || completed) return;
        
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - phaseStartTime;
        
        switch (phase) {
            case PHASE_INITIAL:
                if (elapsed >= INITIAL_DURATION) {
                    nextPhase();
                }
                break;
                
            case PHASE_MEDAL_DESCENDS:
                medalY += MEDAL_DESCENT_SPEED;
                
                if (medalY >= medalTargetY) {
                    medalY = medalTargetY;
                    nextPhase();
                }
                break;
                
            case PHASE_MEDAL_AT_NECK:
                if (elapsed >= MEDAL_AT_NECK_DURATION) {
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_ARRIVE_FIRST:
                peopleMoving = true;
                
                int peopleToShow = (int) Math.min(peopleX.length, elapsed / 600);
                
                for (int i = 0; i < peopleToShow; i++) {
                    peopleStarted[i] = true;
                }
                
                for (int i = 0; i < peopleX.length; i++) {
                    if (peopleStarted[i] && peopleX[i] < peopleFirstTargetX[i]) {
                        peopleX[i] += 4;
                        
                        if (currentTime - lastPeopleJump > 200) {
                            peopleJumpUp = !peopleJumpUp;
                            lastPeopleJump = currentTime;
                        }
                        peopleY[i] = peopleBaseY[i] + (peopleJumpUp ? -JUMP_HEIGHT : 0);
                    } else if (peopleStarted[i] && peopleX[i] >= peopleFirstTargetX[i]) {
                        peopleReachedFirstTarget[i] = true;
                        peopleY[i] = peopleBaseY[i];
                    }
                }
                
                if (elapsed >= PEOPLE_ARRIVE_FIRST_DURATION) {
                    peopleMoving = false;
                    for (int i = 0; i < peopleY.length; i++) {
                        peopleY[i] = peopleBaseY[i];
                    }
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_CELEBRATE:
                if (currentTime - lastPeopleJump > 300) {
                    peopleJumpUp = !peopleJumpUp;
                    lastPeopleJump = currentTime;
                }
                
                for (int i = 0; i < peopleY.length; i++) {
                    if (peopleReachedFirstTarget[i]) {
                        peopleY[i] = peopleBaseY[i] + (peopleJumpUp ? -JUMP_HEIGHT : 0);
                    }
                }
                
                if (elapsed >= PEOPLE_CELEBRATE_DURATION) {
                    for (int i = 0; i < peopleY.length; i++) {
                        peopleY[i] = peopleBaseY[i];
                    }
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_GET_ANGRY:
                if (elapsed >= PEOPLE_ANGRY_DURATION) {
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_MOVE_TO_RALPH:
                boolean allReachedSecond = true;
                for (int i = 0; i < peopleX.length; i++) {
                    if (peopleX[i] < peopleSecondTargetX[i]) {
                        peopleX[i] += 3;  
                        allReachedSecond = false;
                    } else {
                        peopleX[i] = peopleSecondTargetX[i];
                        peopleReachedSecondTarget[i] = true;
                    }
                }
                
                if (elapsed >= PEOPLE_MOVE_TO_RALPH_DURATION || allReachedSecond) {
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_LIFT_RALPH:
                ralphY = ralphInitialY + RALPH_ORIZ_Y_OFFSET;
                
                if (elapsed >= PEOPLE_LIFT_RALPH_DURATION) {
                    nextPhase();
                }
                break;
                
            case PHASE_PEOPLE_MOVE_TO_EDGE:
                boolean allReachedThird = true;
                for (int i = 0; i < peopleX.length; i++) {
                    if (peopleX[i] < peopleThirdTargetX[i]) {
                        int movement = 3;
                        peopleX[i] += movement;
                        
                        if (i == 0) {
                            ralphX += movement;
                        }
                        allReachedThird = false;
                    }
                }
                
                if (elapsed >= PEOPLE_MOVE_TO_EDGE_DURATION || allReachedThird) {
                    ralphLaunchStartX = ralphX;
                    ralphLaunchStartY = ralphY;
                    ralphVelocityX = LAUNCH_VELOCITY_X;
                    ralphVelocityY = LAUNCH_VELOCITY_Y;
                    // ✅ ATTIVA CAMERA TRACKING
                    cameraFollowingRalph = true;
                    nextPhase();
                }
                break;
                
            case PHASE_RALPH_PARABOLIC_LAUNCH:
                ralphX += (int) ralphVelocityX;
                ralphVelocityY += GRAVITY;
                ralphY += (int) ralphVelocityY;
                
                // ✅ AGGIORNA CAMERA
                updateCamera();
                
                if (elapsed >= RALPH_PARABOLIC_LAUNCH_DURATION || ralphY > ralphLaunchStartY + 100) {
                    ralphFallSpeed = CONSTANT_FALL_SPEED;
                    nextPhase();
                }
                break;
                
            case PHASE_RALPH_FALLS:
                ralphFalling = true;
                ralphY += (int) ralphFallSpeed;
                backgroundY += (int) (ralphFallSpeed * 0.4f);
                
                // ✅ CONTINUA A SEGUIRE RALPH ORIZZONTALMENTE
                updateCamera();
                
                if (currentTime - lastSpriteChange > 200) {
                    ralphSpriteIndex = (ralphSpriteIndex + 1) % 4;
                    lastSpriteChange = currentTime;
                }
                
                // Quando Ralph arriva in fondo
                if (ralphY - backgroundY > screenHeight) {
                    // ✅ NON disattivare il tracking, mantieni l'offset
                    cameraFollowingRalph = false; // Smetti di seguire, ma mantieni cameraX
                    nextPhase();
                }
                break;
                
            case PHASE_SWITCH_TO_BASE:
                ralphY = -100;
                ralphX = 1000; 
                backgroundY = 0;
                ralphFallSpeed = CONSTANT_FALL_SPEED;
                ralphSpriteIndex = 0;
                lastSpriteChange = currentTime;
                // ✅ MANTIENI cameraX com'è, non resettarla
                nextPhase();
                break;
                
            case PHASE_RALPH_LANDING:
                // ✅ CONTINUA ad aggiornare la camera smooth
                if (cameraReturning) {
                    updateCameraSmooth();
                }
                
                if (ralphY < RALPH_GROUND_Y) {
                    ralphY += (int) ralphFallSpeed;
                    
                    if (currentTime - lastSpriteChange > 200) {
                        ralphSpriteIndex = (ralphSpriteIndex + 1) % 4;
                        lastSpriteChange = currentTime;
                    }
                } else {
                    ralphY = RALPH_GROUND_Y;
                    ralphSpriteIndex = 0; 
                    
                    long spriteDuration = (ralphLandingSpriteIndex < 2) ? 300 : 2000;
                    
                    if (currentTime - lastSpriteChange > spriteDuration) {
                        ralphLandingSpriteIndex++;
                        lastSpriteChange = currentTime;
                        
                        if (ralphLandingSpriteIndex >= 3) {
                            // ✅ Quando Ralph si alza, inizia il ritorno della camera
                            cameraReturning = true;
                            targetCameraX = 0;
                            nextPhase();
                        }
                    }
                }
                break;

           case PHASE_RALPH_COMING_BACK:
                if (ralphY > 135) {
                    if (currentTime - lastSpriteChange > 300) {
                        ralphSpriteIndex = (ralphSpriteIndex == 0) ? 1 : 0;
                        lastSpriteChange = currentTime;
                    }

                    float moveSpeedX = 7f;
                    float moveSpeedY = 7f;

                    if (ralphX > 644) {
                        ralphX -= (int) moveSpeedX;
                    } else {
                        if (ralphY > 135) {  
                            ralphY -= (int) moveSpeedY;
                        }
                    }
                    
                    // ✅ CONTINUA il ritorno della camera alla posizione iniziale
                    updateCameraSmooth();
                }

                if (ralphY <= 135) {
                    nextPhase();
                }
                break;
                
            case PHASE_END:
                if(elapsed < LAST_PHASE_TIME){
                    // Rimani fermo
                } else {
                    completed = true;
                    active = false;
                    break;
                }
        }
    }
    
    // ✅ AGGIORNA CAMERA PER SEGUIRE RALPH ORIZZONTALMENTE
    private void updateCamera() {
        if (!cameraFollowingRalph) return;
        
        // Se Ralph supera il bordo destro visibile, scorri la camera
        if (ralphX - cameraX > CAMERA_RIGHT_EDGE) {
            targetCameraX = ralphX - CAMERA_RIGHT_EDGE;
        }
        
        updateCameraSmooth();
    }
    
    // ✅ MOVIMENTO FLUIDO DELLA CAMERA
    private void updateCameraSmooth() {
        // Interpolazione lineare per movimento fluido
        cameraX += (targetCameraX - cameraX) * CAMERA_SMOOTH_FACTOR;
    }
    
    private void nextPhase() {
        phase++;
        phaseStartTime = System.currentTimeMillis();
    }
    
    public void draw(Graphics2D g2, int screenWidth, int screenHeight) {
        if (!active) return;
        
        BufferedImage ralphSprite = null;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, screenWidth, screenHeight);
        
        BufferedImage currentBackground = (phase >= PHASE_SWITCH_TO_BASE) ? backgroundBase : background;
        
        // ✅ OFFSET CAMERA per tutto (background e sprite) - SEMPRE ATTIVO
        int drawOffsetX = -(int)cameraX;
        
        if (currentBackground != null) {
            if (phase < PHASE_SWITCH_TO_BASE) {
                // Background normale con offset camera
                g2.drawImage(currentBackground, 401 + drawOffsetX, 440, 1052 + drawOffsetX, 854, 
                             0, 0, 232, 180, null);
            } else {
                // ✅ Background della base CON OFFSET CAMERA
                g2.drawImage(currentBackground, 401 + drawOffsetX, 21, 1052 + drawOffsetX, 848, 
                             0,0,232,316,null);
            }
        }
        
        // Disegna Felix (con offset camera nelle fasi iniziali)
        if (phase < PHASE_SWITCH_TO_BASE) {
            BufferedImage felixSprite = (phase >= PHASE_MEDAL_AT_NECK) 
                                        ? felixStandingMedal : felixStanding;
            if (felixSprite != null) {
                int width = (int) (felixSprite.getWidth(null) * 2.5);
                int height = (int) (felixSprite.getHeight(null) * 2.5);
                g2.drawImage(felixSprite, felixX + drawOffsetX, felixY, width, height, null);
            }
        }
        
        // Medaglia
        if (phase >= PHASE_MEDAL_DESCENDS && phase < PHASE_MEDAL_AT_NECK) {
            BufferedImage medalImage = getMedalImageByProgress();
            
            if (medalImage != null) {
                int medalDrawX = (int)(medalX) + drawOffsetX;
                int medalDrawY = (int)(medalY - backgroundY);
                g2.drawImage(medalImage, medalDrawX, medalDrawY, (int)MEDAL_SIZE, (int)MEDAL_SIZE, null);
            }
        }
        
        // Ralph
        if (phase >= PHASE_INITIAL) {
            
            if (phase < PHASE_PEOPLE_LIFT_RALPH) {
                ralphSprite = ralphStanding;
            } else if (phase >= PHASE_PEOPLE_LIFT_RALPH && phase < PHASE_RALPH_FALLS) {
                ralphSprite = ralphOriz;
            } else if (phase >= PHASE_RALPH_FALLS && phase < PHASE_RALPH_LANDING) {
                switch (ralphSpriteIndex) {
                    case 0: ralphSprite = ralphFalling1; break;
                    case 1: ralphSprite = ralphFalling2; break;
                    case 2: ralphSprite = ralphFalling3; break;
                    case 3: ralphSprite = ralphFalling4; break;
                }
            } else if (phase == PHASE_RALPH_LANDING) {
                if (ralphY < RALPH_GROUND_Y) {
                    switch (ralphSpriteIndex) {
                        case 0: ralphSprite = ralphFalling1; break;
                        case 1: ralphSprite = ralphFalling2; break;
                        case 2: ralphSprite = ralphFalling3; break;
                        case 3: ralphSprite = ralphFalling4; break;
                    }
                } else {
                    switch (ralphLandingSpriteIndex) {
                        case 0: ralphSprite = ralphLanding1; break;
                        case 1: ralphSprite = ralphLanding2; break;
                        case 2: 
                        default: ralphSprite = ralphLanding3; break;
                    }
                }
            }
            
            if (ralphSprite != null) {
                int width = (int) (ralphSprite.getWidth(null) * 2.5);
                int height = (int) (ralphSprite.getHeight(null) * 2.5);
                // ✅ USA SEMPRE drawOffsetX sia prima che dopo il cambio background
                int drawY = (phase < PHASE_SWITCH_TO_BASE) ? ralphY - backgroundY : ralphY;
                int drawX = ralphX + drawOffsetX; // Sempre con offset
                g2.drawImage(ralphSprite, drawX, drawY, width, height, null);
            }
        }
        
        // Abitanti (con offset camera)
        if (phase < PHASE_SWITCH_TO_BASE) {
            BufferedImage[] currentPeopleImages = (phase >= PHASE_PEOPLE_GET_ANGRY) 
                                                   ? peopleImagesAngry : peopleImagesHappy;
            
            if (currentPeopleImages != null && phase >= PHASE_PEOPLE_ARRIVE_FIRST) {
                for (int i = 0; i < currentPeopleImages.length; i++) {
                    if (peopleStarted[i] && currentPeopleImages[i] != null) {
                        int width = (int) (currentPeopleImages[i].getWidth(null) * 2.5);
                        int height = (int) (currentPeopleImages[i].getHeight(null) * 2.5);
                        g2.drawImage(currentPeopleImages[i], 
                            peopleX[i] + drawOffsetX, 
                            peopleY[i], 
                            width, height, null);
                    }
                }
            }
        }

        // ✅ Ralph che torna - CON OFFSET CAMERA
        if(phase >= PHASE_RALPH_COMING_BACK){
            
            if(ralphX >= 644){
                switch (ralphSpriteIndex){
                    case 0: ralphSprite = ralphMoveLeft0; break;
                    case 1: ralphSprite = ralphMoveLeft1; break;
                }
            }
            else{
                if(ralphY >= 136){
                    switch (ralphSpriteIndex){
                        case 0: ralphSprite = ralphBack1; break;
                        case 1: ralphSprite = ralphBack2; break;
                    }
                }
            }
            if(ralphSprite != null){
                int width = (int) (ralphSprite.getWidth(null) * 2);
                int height = (int) (ralphSprite.getHeight(null) * 2);
                g2.drawImage(ralphSprite, ralphX + drawOffsetX, ralphY+25, width, height, null);
            }

            if(phase >= PHASE_END){
                ralphSprite = ralphStanding2;
                if(ralphSprite != null){
                    int width = (int) (ralphSprite.getWidth(null) * 2);
                    int height = (int) (ralphSprite.getHeight(null) * 2);
                    g2.drawImage(ralphSprite, ralphX + drawOffsetX, ralphY, width, height, null);
                }
            }
        }
    }
    
    private BufferedImage getMedalImageByProgress() {
        float totalDistance = medalTargetY - (felixY - 200);
        float currentDistance = medalY - (felixY - 200);
        float progress = currentDistance / totalDistance;
        
        if (progress < 0.33f) {
            return medalImage1;
        } else if (progress < 0.66f) {
            return medalImage2;
        } else {
            return medalImage3;
        }
    }
    
    public boolean isActive() {
        return active;
    }
    
    public boolean isCompleted() {
        return completed;
    }
}