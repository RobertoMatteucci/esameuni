import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class TileManager {

    GamePanel gp;
    RalphCutscene rcs;
    LivelloN livN;
    public boolean livelloInTransizione = false;
    public boolean attivaRicostruzione = false;

    private BufferedImage background;
    private int backgroundY;
    private int backgroundY1;
    private static final int SCREEN_HEIGHT = 848;
    private static final int SCROLL_SPEED = 4;

    public Tile[] tile;
    public ArrayList<Rectangle> collisionTiles = new ArrayList<>();
    public ArrayList<Rectangle> collisioneFinestre = new ArrayList<>();
    public Window[] animazioneFinestre;

    public int count = 18;
    private int windowWidth = 75;
    private int windowHeight = 128;
    private int gapX = 15;
    private int gapY = -2;

    // Ralph cutscene
    private BufferedImage ralphBack1, ralphBack2;
    private int ralphX = 655, ralphY = 135;
    private boolean showCutscene = false;
    private boolean toggleImage = false;
    private long cutsceneStartTime;
    private static final int CUTSCENE_DURATION = 5000;
    private static final int RALPH_SPEED = 4;
    public boolean transition = false;

    // Livello completato
    public LivelloCompletato livelloCompletatoManager;
    private boolean livelloCompletato = false;
    private boolean scrollingInCorso = false;

    // Timer e bonus
    private ArrayList<BonusText> bonusTexts = new ArrayList<>();
    private TimeBar timeBar;
    private long startTime;
    private final int TEMPO_MASSIMO = 120;
    private boolean timerAvviato = false;
    
    // Bonus visual
    private int bonusVisual = 0;
    private boolean showBonus = false;
    private long bonusStartTime;
    
    // ✅ FONT ARCADE
    private Font arcadeFont;

    // Gestione Pie (Torta)
    public Pie pie;
    private long pieSystemStartTime = 0;
    private long nextPieSpawnDelay = 0;
    private final long MIN_PIE_SPAWN_INTERVAL = 20000;
    private final long MAX_PIE_SPAWN_INTERVAL = 35000;
    private final long PIE_DURATION = 10000;
    private long pieSpawnedAt = 0;

    public TileManager(GamePanel gp, LivelloN livN) {
        this.gp = gp;
        this.livN = livN;
        this.rcs = new RalphCutscene(ralphX, ralphY, RALPH_SPEED, 0, 0, 0, 0, 0, 0);
        this.pie = new Pie();
        
        tile = new Tile[5];
        count = livN.getFinestreDaAggiustare();
        animazioneFinestre = new Window[count];
        
        loadBackground();
        loadArcadeFont(); // ✅ Carica font arcade
        initializeCollisionTiles();
        initializeCollisioneFinestre();

        livelloCompletatoManager = new LivelloCompletato(
            gp,
            collisionTiles,
            collisioneFinestre,
            windowWidth,
            windowHeight,
            gapX,
            gapY,
            livN
        );
    }

    private void loadBackground() {
        try {
            background = ImageIO.read(getClass().getResourceAsStream("/map/PalazzoCompleto.png"));
            backgroundY = background.getHeight() - 318;
            backgroundY1 = background.getHeight();

            ralphBack1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack1.png"));
            ralphBack2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack2.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // ✅ CARICA FONT ARCADE (Press Start 2P o similare)
    private void loadArcadeFont() {
        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            if (is != null) {
                arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(Font.BOLD, 24f);
                System.out.println("✅ Font arcade caricato!");
            } else {
                arcadeFont = new Font("Monospaced", Font.BOLD, 24);
                System.out.println("⚠️ Font arcade non trovato, uso Monospaced");
            }
        } catch (Exception e) {
            arcadeFont = new Font("Monospaced", Font.BOLD, 24);
            System.out.println("⚠️ Errore caricamento font, uso Monospaced");
        }
    }

    private void calculateNextSpawnDelay() {
        nextPieSpawnDelay = MIN_PIE_SPAWN_INTERVAL + 
            (long) (Math.random() * (MAX_PIE_SPAWN_INTERVAL - MIN_PIE_SPAWN_INTERVAL));
        
        System.out.println("🍰 Prossima torta tra " + (nextPieSpawnDelay / 1000) + " secondi dall'inizio del timer");
    }
    
    private void trySpawnPie() {
        if (pieSystemStartTime == 0) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        long elapsedSinceStart = currentTime - pieSystemStartTime;
        
        if (pie.isActive() && currentTime - pieSpawnedAt >= PIE_DURATION) {
            System.out.println("🍰 Torta scaduta! Scompare...");
            pie.reset();
            calculateNextSpawnDelay();
        }
        
        if (!pie.isActive() && elapsedSinceStart >= nextPieSpawnDelay) {
            
            if (collisioneFinestre.size() > 0) {
                int randomIndex = (int) (Math.random() * collisioneFinestre.size());
                Rectangle randomWindow = collisioneFinestre.get(randomIndex);
                
                pie.spawn(randomWindow);
                pieSpawnedAt = currentTime;
                
                System.out.println("🍰 Torta spawned! Scomparirà tra " + (PIE_DURATION / 1000) + " secondi");
                
                calculateNextSpawnDelay();
                pieSystemStartTime = currentTime;
            }
        }
    }

    public void aggiustaFinestra(Rectangle martello) {
        for (int i = 0; i < collisioneFinestre.size(); i++) {
            if (!animazioneFinestre[i].isRiparata() && martello.intersects(collisioneFinestre.get(i))) {
                
                if (!timerAvviato) {
                    startLevelTimer();
                    timerAvviato = true;
                    
                    pieSystemStartTime = System.currentTimeMillis();
                    calculateNextSpawnDelay();
                    
                    System.out.println("⏱️ Timer avviato!");
                    System.out.println("🍰 Sistema torta inizializzato!");
                }

                animazioneFinestre[i].ripara();
                count--;
                
                // ✅ AGGIUNGI 100 PUNTI PER FINESTRA (invece di 50)
                int textX = martello.x + martello.width / 2;
                int textY = martello.y;
                bonusTexts.add(new BonusText(textX, textY, 100)); // 100 punti
                
                // Aggiungi punti allo score manager
                gp.scoreManager.addPoints(100);
                
                if (count == 0) {
                    gp.ralph.transition = true;
                    showCutscene = true;
                    cutsceneStartTime = System.currentTimeMillis();
                }
                return;
            }
        }
    }

    public void update() {
        if (livelloInTransizione) {
            gp.player.setActive(false);
            if (backgroundY > 70) {
                gp.player.y += SCROLL_SPEED;
                backgroundY -= SCROLL_SPEED;
                backgroundY1 -= SCROLL_SPEED;
            } else {
                livelloInTransizione = false;
                attivaRicostruzione = true;
            }
        }

        if (!livelloInTransizione && animazioneFinestre != null) {
            for (Window finestra : animazioneFinestre) {
                finestra.update();
            }
        }

        if (showCutscene) {
            long elapsed = System.currentTimeMillis() - cutsceneStartTime;

            if (elapsed < CUTSCENE_DURATION) {
                if (elapsed % 300 < 150) {
                    toggleImage = true;
                } else {
                    toggleImage = false;
                }
                ralphY -= RALPH_SPEED;
            } else {
                showCutscene = false;
                gp.ralph.transition = false;
                
                if (timerAvviato) {
                    long tempoTrascorso = (System.currentTimeMillis() - startTime) / 1000;
                    int tempoEffettivo = (int) tempoTrascorso;
                    int bonus = calcolaBonus(tempoEffettivo);
                    gp.scoreManager.addPoints(bonus);
                    
                    bonusVisual = bonus;
                    showBonus = true;
                    bonusStartTime = System.currentTimeMillis();
                    
                    System.out.println("💰 Bonus tempo: " + bonus + " punti!");
                    
                    int totalScore = gp.scoreManager.getScore();
                    if (HighScoreManager.isHighScore(totalScore)) {
                        HighScoreManager.saveHighScore(totalScore);
                    }
                }
                
                startScroll();
            }
        }
        
        if (showBonus && (System.currentTimeMillis() - bonusStartTime > 2000)) {
            showBonus = false;
        }
        
        if (!livelloInTransizione && !showCutscene && timerAvviato && pieSystemStartTime > 0) {
            trySpawnPie();
            pie.update();
            
            if (gp.player != null && gp.player.getHitbox() != null && !gp.player.isEating()) {
                if (pie.checkCollision(gp.player.getHitbox())) {
                    gp.player.startEatingAnimation();
                    pie.startEating();
                    gp.scoreManager.addPoints(50);
                    
                    System.out.println("🍰 Felix sta mangiando la torta!");
                    
                    new Thread(() -> {
                        try {
                            Thread.sleep(2000);
                            pie.consume();
                            System.out.println("🍰 Torta consumata!");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();
                }
            }
        }
        
        if (timerAvviato && timeBar != null) {
            timeBar.update();
        }
        
        // ✅ AGGIORNA TUTTI I BONUS TEXT
        for (BonusText bt : bonusTexts) {
            bt.update();
        }
    }

    public void draw(Graphics2D g2) {
        if (livN != null && livN.getNumeroLivello() % 2 != 0 && !livelloInTransizione) {
            backgroundY = background.getHeight() - 318;
            backgroundY1 = background.getHeight();
        }
        
        g2.drawImage(background, 401, 21, 1052, SCREEN_HEIGHT,
                     0, backgroundY, 232, backgroundY1, null);

        if (count > 0 && !livelloInTransizione) {
            for (Window finestra : animazioneFinestre) {
                finestra.draw(g2);
            }
        }

        if (showCutscene) {
            BufferedImage currentImg = toggleImage ? ralphBack1 : ralphBack2;
            int scaledWidth = ralphBack1.getWidth() * 2;
            int scaledHeight = ralphBack1.getHeight() * 2;
            rcs.spawnFallingObjects();
            g2.drawImage(currentImg, ralphX, ralphY, scaledWidth, scaledHeight, null);
        }
        
        if (timerAvviato && pieSystemStartTime > 0) {
            pie.draw(g2);
        }
        
        // ✅ TIMER RIMOSSO DA QUI - Verrà disegnato in GamePanel fuori dalla clip region
        
        if (showBonus) {
            g2.setFont(arcadeFont.deriveFont(36f));
            g2.setColor(Color.BLACK);
            // Ombra
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (dx != 0 || dy != 0) {
                        g2.drawString("+" + bonusVisual + " TIME BONUS!", 552 + dx, 102 + dy);
                    }
                }
            }
            g2.setColor(Color.YELLOW);
            g2.drawString("+" + bonusVisual + " TIME BONUS!", 552, 102);
        }
        
        ArrayList<BonusText> toRemove = new ArrayList<>();

        for (BonusText bt : bonusTexts) {
            bt.draw(g2, arcadeFont); // Passa il font arcade
            if (bt.isExpired()) {
                toRemove.add(bt);
            }
        }
        bonusTexts.removeAll(toRemove);
    }
    
    // ✅ METODO PUBBLICO PER DISEGNARE IL TIMER FUORI DALLA CLIP REGION
    public void drawTimer(Graphics2D g2) {
        if (timerAvviato && timeBar != null) {
            timeBar.draw(g2);
        }
    }
    
    // ✅ METODO PER VERIFICARE SE IL TIMER È ATTIVO
    public boolean isTimerActive() {
        return timerAvviato && timeBar != null;
    }

    public void initializeCollisionTiles() {
        collisionTiles.clear();
        collisionTiles.add(new Rectangle(513, 661, 440, 1));
        collisionTiles.add(new Rectangle(510, 789, 152, 1));
        collisionTiles.add(new Rectangle(803, 789, 152, 1));
        collisionTiles.add(new Rectangle(513, 519, 440, 1));
        collisionTiles.add(new Rectangle(513, 394, 440, 1));
    }

    public void initializeCollisioneFinestre() {
        collisioneFinestre.clear();
        collisioneFinestre.add(new Rectangle(714, 341, windowWidth - 30, windowHeight - 65));
        collisioneFinestre.add(new Rectangle(714, 467, windowWidth - 30, windowHeight - 65));

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                int x = 520 + j * (windowWidth + gapX);
                int y = 609 + i * (windowHeight + gapY);
                collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
            }
            for (int j = 0; j < 2; j++) {
                int x = 814 + j * (windowWidth + 13);
                int y = 609 + i * (windowHeight + gapY);
                collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
            }
            for (int j = 0; j < 2; j++) {
                int x = 520 + j * (windowWidth + gapX);
                int y = 341 + i * (windowHeight + gapY);
                collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
            }
            for (int j = 0; j < 2; j++) {
                int x = 811 + j * (windowWidth + 13);
                int y = 341 + i * (windowHeight + (-2));
                collisioneFinestre.add(new Rectangle(x, y, windowWidth - 30, windowHeight - 65));
            }
        }

        animazioneFinestre = new Window[collisioneFinestre.size()];
        for (int i = 0; i < collisioneFinestre.size(); i++) {
            animazioneFinestre[i] = new Window(collisioneFinestre.get(i).x, collisioneFinestre.get(i).y);
            animazioneFinestre[i].getTileImage();
        }
    }

    public void startScroll() {
        gp.player.setActive(false);
        livelloInTransizione = true;
        attivaRicostruzione = false;
    }
    
    public void startLevelTimer() {
        startTime = System.currentTimeMillis();
        timeBar = new TimeBar(TEMPO_MASSIMO);
        System.out.println("⏱️ Timer creato con tempo massimo: " + TEMPO_MASSIMO + "s");
    }
    
    private int calcolaBonus(int tempo) {
        if (tempo <= 30) return 2000;
        else if (tempo <= 40) return 1000;
        else if (tempo <= 50) return 600;
        else if (tempo <= 60) return 500;
        else if (tempo <= 70) return 400;
        else if (tempo <= 80) return 200;
        else if (tempo <= 120) return 100;
        else return 0;
    }
    
    public void resetTimer() {
        System.out.println("🔄 Reset timer e torta per nuovo livello");
        timerAvviato = false;
        timeBar = null;
        bonusTexts.clear();
        showBonus = false;
        
        pie.reset();
        pieSystemStartTime = 0;
        nextPieSpawnDelay = 0;
        pieSpawnedAt = 0;
        
        System.out.println("🍰 Sistema torta completamente resettato");
    }

    public ArrayList<Rectangle> getCollisionTiles() {
        return collisionTiles;
    }

    public ArrayList<Rectangle> getCollisioneFinestre() {
        return collisioneFinestre;
    }

    public boolean isLivelloInTransizione() {
        return livelloInTransizione;
    }
    
    public Pie getPie() {
        return pie;
    }
}