import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class RalphCutscene {
    private int x, y;
    private int speed, jumpSpeed;
    private int startX, startY;
    private int targetX1, targetX2, targetY1, targetY2, finalX;
    private int phase;
    private boolean movingLeft;
    private Image finalPose1, finalPose2, extraImage;
    private Image image1, image2, jump1, jump2, jump3, exit1, exit2;
    private int frameCount, finalAnimationFrames;
    private boolean cutsceneFinished = false;
    
    // Lista di oggetti che cadono
    public ArrayList<FallingObject> fallingObjects;
    
    // ✅ PRE-CARICA LE IMMAGINI UNA VOLTA SOLA!
    private Image objectImage1, objectImage2, objectImage3, objectImage4;

    public RalphCutscene(int startX, int startY, int speed, int jumpSpeed, int targetX1, int targetX2, int targetY1, int targetY2, int finalX) {
        this.x = startX;
        this.y = startY;
        this.startX = startX;
        this.startY = startY;
        this.speed = speed;
        this.jumpSpeed = jumpSpeed;
        this.targetX1 = targetX1;
        this.targetX2 = targetX2;
        this.targetY1 = targetY1;
        this.targetY2 = targetY2;
        this.finalX = finalX;
        this.phase = 0;
        this.movingLeft = true;
        this.finalAnimationFrames = 0;

        fallingObjects = new ArrayList<>();

        loadImages();
    }
    
    private void loadImages() {
        try {
            this.image1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack1.png"));
            this.image2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack2.png"));
            this.jump1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphUp0.png"));
            this.jump2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphUp1.png"));
            this.jump3 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphUp2.png"));
            this.exit1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphMoveLeft0.png"));
            this.exit2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphMoveLeft1.png"));
            this.finalPose1 = ImageIO.read(getClass().getResourceAsStream("/ralph/Move9.png"));
            this.finalPose2 = ImageIO.read(getClass().getResourceAsStream("/ralph/Move10.png"));
            this.extraImage = ImageIO.read(getClass().getResourceAsStream("/ralph/MessageRalph0.png"));
            
            // ✅ CARICA LE IMMAGINI DEGLI OGGETTI UNA VOLTA SOLA
            this.objectImage1 = ImageIO.read(getClass().getResourceAsStream("/map/rotta1.png"));
            this.objectImage2 = ImageIO.read(getClass().getResourceAsStream("/map/rotta2.png"));
            this.objectImage3 = ImageIO.read(getClass().getResourceAsStream("/map/rotta3.png"));
            this.objectImage4 = ImageIO.read(getClass().getResourceAsStream("/map/rotta4.png"));
            
            System.out.println("RalphCutscene: Tutte le immagini caricate con successo");
        } catch (IOException e) {
            System.err.println("RalphCutscene: Errore nel caricamento delle immagini");
            e.printStackTrace();
        }
    }
    
    public void update() {
        switch (phase) {
            case 0:
                finalAnimationFrames++;
                if (finalAnimationFrames > 100) {
                    phase = 1;
                    finalAnimationFrames = 0;
                }
                break;
            case 1:
                if (x < targetX1) {
                    x += speed;
                    spawnFallingObjects();
                } else {
                    phase = 2;
                }
                break;
            case 2:
                if (y > targetY1)
                    y -= jumpSpeed;
                else 
                    phase = 3;
                break;
            case 3:
                if (x > targetX2) {
                    x -= speed;
                    spawnFallingObjects();
                } else {
                    phase = 4;
                }
                break;
            case 4:
                if (x < targetX1) {
                    x += speed;
                    spawnFallingObjects();
                } else {
                    phase = 5;
                }
                break;
            case 5:
                if (y > targetY2)
                    y -= jumpSpeed;
                else 
                    phase = 6;
                break;
            case 6:
                if (x > finalX)
                    x -= speed;
                else 
                    phase = 7;
                break;
            case 7:
                finalAnimationFrames++;
                if (finalAnimationFrames > 100) {
                    cutsceneFinished = true;
                }
                break;
        }
    
        if (phase < 7) {
            frameCount++;
            if (frameCount % 10 == 0) {
                movingLeft = !movingLeft;
            }
        }
        
        if (phase == 7 && cutsceneFinished) {
            fallingObjects.clear();
        }
        
        // Aggiorna gli oggetti che cadono
        ArrayList<FallingObject> toRemove = new ArrayList<>();
        for (FallingObject fallingObject : fallingObjects) {
            fallingObject.update();
            if (fallingObject.isOffScreen()) {
                toRemove.add(fallingObject);
            }
        }
        fallingObjects.removeAll(toRemove);
    }

    public void draw(Graphics2D g2) {
        Image currentImage = image1;

        if (phase == 0) {
            int extraX = x + 50;
            int extraY = y - 50;
            if (extraImage != null) {
                g2.drawImage(extraImage, extraX, extraY, 250, 70, null);
            }
      
            if (frameCount % 50 < 25) {
                currentImage = finalPose1;
            } else {
                currentImage = finalPose2;
            }
        } else if (phase == 2 || phase == 5) {
            if (frameCount % 30 < 10) currentImage = jump1;
            else if (frameCount % 30 < 20) currentImage = jump2;
            else currentImage = jump3;
        } else if (phase == 6) {
            currentImage = movingLeft ? exit1 : exit2;
        } else {
            currentImage = movingLeft ? image1 : image2;
        }
        
        if (phase == 7) {
            if (finalAnimationFrames % 50 < 25) {
                currentImage = finalPose1;
            } else {
                currentImage = finalPose2;
            }
        }
        
        if (currentImage != null) {
            int newWidth = (int) (currentImage.getWidth(null) * 2);
            int newHeight = (int) (currentImage.getHeight(null) * 2);
            g2.drawImage(currentImage, x, y, newWidth, newHeight, null);
        }

        // Disegna gli oggetti che cadono
        for (FallingObject fallingObject : fallingObjects) {
            fallingObject.draw(g2);
        }
    }

    public void reset() {
        this.x = startX;
        this.y = startY;
        this.phase = 0;
        this.frameCount = 0;
        this.finalAnimationFrames = 0;
        this.cutsceneFinished = false;
        fallingObjects.clear();
    }

    public void spawnFallingObjects() {
        // ✅ OTTIMIZZATO: Ridotta frequenza di spawn e solo durante movimento orizzontale
        // Spawn solo ogni N updates per ridurre il numero di oggetti
        double probability = 0.13; // Ulteriormente ridotto
        
        if (Math.random() < probability && fallingObjects.size() < 10) { // Max 10 oggetti contemporanei
            int randomObject = (int) (Math.random() * 4);
            
            // ✅ USA LE IMMAGINI PRE-CARICATE
            Image objectImage = null;
            switch (randomObject) {
                case 0: objectImage = objectImage1; break;
                case 1: objectImage = objectImage2; break;
                case 2: objectImage = objectImage3; break;
                case 3: objectImage = objectImage4; break;
            }
            
            if (objectImage != null) {
                int offsetX = (int) (Math.random() * 60 - 30);
                int offsetY = (int) (Math.random() * 30 - 15);
                fallingObjects.add(new FallingObject(x, y, offsetX, offsetY, 5, objectImage));
            }
        }
    }

    public int getPhase() {
        return phase;
    }
    
    public boolean isFinished() {
        return cutsceneFinished;
    }
}