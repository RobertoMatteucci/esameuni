import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

public class Pie {
    
    private int x, y;
    private boolean active = false;
    private boolean spawning = false;
    private boolean spawned = false;
    private boolean eating = false;
    private boolean consumed = false;
    
    // Immagini - 3 abitanti diversi, ognuno con 2 sprite
    private BufferedImage[][] abitanti; // [abitante][frame]
    private BufferedImage torta1, torta2;
    
    // ✅ RANDOM per scegliere abitante casuale
    private Random random;
    
    // Abitante corrente (casuale)
    private int currentAbitante = 0;
    
    // Animazione spawn (abitante che appare)
    private int spawnFrame = 0;
    private int spawnFrameCounter = 0;
    private final int spawnAnimationSpeed = 15; // Velocità animazione spawn
    private final int maxSpawnFrames = 3; // 3 frame: abitante1, abitante2 lungo, transizione
    private final int frame2Duration = 45; // Durata più lunga per il secondo frame dell'abitante
    
    // Animazione torta (alternanza sprite)
    private int pieFrame = 0;
    private int pieFrameCounter = 0;
    private final int pieAnimationSpeed = 30; // Velocità alternanza sprite torta
    
    // Transizione
    private boolean showingTransition = false; // Mostra sia abitante che torta
    
    // Hitbox
    private Rectangle hitbox;
    private final int hitboxWidth = 25;
    private final int hitboxHeight = 15;
    
    // Dimensioni sprite
    private final int spriteScale = 2;
    
    // Numero di abitanti disponibili
    private final int NUM_ABITANTI = 3;
    
    public Pie() {
        abitanti = new BufferedImage[NUM_ABITANTI][2];
        random = new Random(); // ✅ Inizializza Random
        loadImages();
        hitbox = new Rectangle(0, 0, hitboxWidth, hitboxHeight);
    }
    
    private void loadImages() {
        try {
            // Carica immagini dei 3 abitanti (ogni abitante ha 2 sprite)
            // Abitante tipo "t"
            abitanti[0][0] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t_1.png"));
            abitanti[0][1] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t_2.png"));
            
            // Abitante tipo 2
            abitanti[1][0] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t2_1.png"));
            abitanti[1][1] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t2_2.png"));
            
            // Abitante tipo 3
            abitanti[2][0] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t1_1.png"));
            abitanti[2][1] = ImageIO.read(getClass().getResourceAsStream("/abitanti/Abitante_t1_2.png"));
            
            // Carica immagini torta
            torta1 = ImageIO.read(getClass().getResourceAsStream("/torta/Pie1.png"));
            torta2 = ImageIO.read(getClass().getResourceAsStream("/torta/Pie2.png"));
            
            System.out.println("✅ Immagini torta e abitanti caricate con successo!");
            
        } catch (IOException e) {
            System.err.println("❌ Errore nel caricamento delle immagini della torta o degli abitanti");
            e.printStackTrace();
        }
    }
    
    // Spawna la torta in una finestra casuale
    public void spawn(Rectangle windowPosition) {
        if (!active && !consumed) {
            this.x = windowPosition.x;
            this.y = windowPosition.y;
            this.active = true;
            this.spawning = true;
            this.spawned = false;
            this.spawnFrame = 0;
            this.spawnFrameCounter = 0;
            this.showingTransition = false;
            
            // ✅ SCEGLI UN ABITANTE CASUALE
            currentAbitante = random.nextInt(NUM_ABITANTI);
            
            // Aggiorna hitbox
            hitbox.x = x;
            hitbox.y = y;
            
            System.out.println("🍰 Torta spawning alla posizione: " + x + ", " + y + " - Abitante casuale: " + currentAbitante);
        }
    }
    
    public void update() {
        if (!active) return;
        
        // Animazione spawn (abitante che lascia la torta)
        if (spawning) {
            spawnFrameCounter++;
            
            // Frame 0: abitante1 (durata normale)
            if (spawnFrame == 0 && spawnFrameCounter >= spawnAnimationSpeed) {
                spawnFrameCounter = 0;
                spawnFrame = 1;
            }
            // Frame 1: abitante2 (durata più lunga)
            else if (spawnFrame == 1 && spawnFrameCounter >= frame2Duration) {
                spawnFrameCounter = 0;
                spawnFrame = 2;
                showingTransition = true; // Inizia la transizione
            }
            // Frame 2: transizione con entrambi visibili
            else if (spawnFrame == 2 && spawnFrameCounter >= spawnAnimationSpeed) {
                spawning = false;
                spawned = true; // La torta è ora visibile
                showingTransition = false;
                spawnFrame = 0;
            }
        }
        
        // Animazione torta (alternanza sprite)
        if (spawned && !eating) {
            pieFrameCounter++;
            if (pieFrameCounter >= pieAnimationSpeed) {
                pieFrameCounter = 0;
                pieFrame = (pieFrame + 1) % 2; // Alterna tra 0 e 1
            }
        }
    }
    
    public void draw(Graphics2D g2) {
        if (!active) return;
        
        BufferedImage currentImage = null;
        
        // Disegna l'animazione di spawn (abitante)
        if (spawning) {
            if (spawnFrame == 0) {
                currentImage = abitanti[currentAbitante][0];
            } else if (spawnFrame == 1) {
                currentImage = abitanti[currentAbitante][1];
            } else if (spawnFrame == 2) {
                // Frame di transizione: mostra sia abitante che torta
                currentImage = abitanti[currentAbitante][1];
            }
            
            // Disegna l'abitante
            if (currentImage != null) {
                int width = currentImage.getWidth() * spriteScale;
                int height = currentImage.getHeight() * spriteScale;
                g2.drawImage(currentImage, x + 6, y + 23, width, height, null);
            }
            
            // Durante la transizione, mostra anche la torta
            if (showingTransition) {
                BufferedImage pieImage = torta1;
                if (pieImage != null) {
                    int pieWidth = pieImage.getWidth() * spriteScale;
                    int pieHeight = pieImage.getHeight() * spriteScale;
                    g2.drawImage(pieImage, x + 6, y + 23, pieWidth, pieHeight, null);
                }
            }
        }
        // Disegna la torta
        else if (spawned && !eating) {
            if (pieFrame == 0) {
                currentImage = torta1;
            } else {
                currentImage = torta2;
            }
            
            if (currentImage != null) {
                int width = currentImage.getWidth() * spriteScale;
                int height = currentImage.getHeight() * spriteScale;
                g2.drawImage(currentImage, x + 6, y + 23, width, height, null);
            }
        }
    }
    
    // Verifica collisione con Felix
    public boolean checkCollision(Rectangle felixHitbox) {
        if (spawned && !eating && !consumed) {
            return hitbox.intersects(felixHitbox);
        }
        return false;
    }
    
    // Inizia l'animazione di Felix che mangia (sarà gestita in Player.java)
    public void startEating() {
        if (spawned && !eating && !consumed) {
            eating = true;
            System.out.println("🍰 Felix sta mangiando la torta!");
        }
    }
    
    // La torta è stata consumata
    public void consume() {
        consumed = true;
        active = false;
        spawned = false;
        eating = false;
        System.out.println("🍰 Torta consumata completamente!");
    }
    
    // Getters
    public boolean isActive() {
        return active;
    }
    
    public boolean isSpawned() {
        return spawned;
    }
    
    public boolean isEating() {
        return eating;
    }
    
    public boolean isConsumed() {
        return consumed;
    }
    
    public Rectangle getHitbox() {
        return hitbox;
    }
    
    // Reset per un nuovo spawn
    public void reset() {
        active = false;
        spawning = false;
        spawned = false;
        eating = false;
        consumed = false;
        spawnFrame = 0;
        pieFrame = 0;
        showingTransition = false;
        System.out.println("🔄 Pie resettata");
    }
}