import java.awt.*;

public class BonusText {
    int x, y;
    int points;
    long startTime;
    
    // ✅ ANIMAZIONE STILE DONKEY KONG
    private int initialY;
    private final int FLOAT_DISTANCE = 50; // Sale di 50 pixel
    private final long DURATION = 1500; // 1.5 secondi

    public BonusText(int x, int y, int points) {
        this.x = x;
        this.y = y;
        this.initialY = y; // ✅ Memorizza la posizione iniziale
        this.points = points;
        this.startTime = System.currentTimeMillis();
    }

    // ✅ AGGIORNA LA POSIZIONE (chiamato nel TileManager.update())
    public void update() {
        long elapsed = System.currentTimeMillis() - startTime;
        float progress = Math.min(1.0f, elapsed / (float) DURATION);
        
        // ✅ MOVIMENTO VERSO L'ALTO (easing out - rallenta progressivamente)
        float easeOut = 1.0f - (float) Math.pow(1.0f - progress, 3);
        y = initialY - (int) (FLOAT_DISTANCE * easeOut);
    }

    // ✅ DISEGNA CON ANIMAZIONE (chiamato nel TileManager.draw())
    public void draw(Graphics2D g2, Font arcadeFont) {
        long elapsed = System.currentTimeMillis() - startTime;
        float progress = elapsed / (float) DURATION;
        
        // ✅ FADE OUT NELL'ULTIMA PARTE DELL'ANIMAZIONE (ultimi 30%)
        float alpha = 1.0f;
        if (progress > 0.7f) {
            alpha = 1.0f - ((progress - 0.7f) / 0.3f);
        }
        
        // ✅ APPLICA TRASPARENZA
        int alphaValue = (int) (255 * Math.max(0, Math.min(1, alpha)));
        Color textColor = new Color(255, 255, 0, alphaValue); // Giallo con trasparenza
        Color shadowColor = new Color(0, 0, 0, alphaValue / 2); // Ombra semi-trasparente
        
        // ✅ DISEGNA CON FONT ARCADE PIÙ PICCOLO E PLAIN (meno spesso)
        g2.setFont(arcadeFont.deriveFont(Font.PLAIN, 18f)); // PLAIN invece di BOLD, size 18
        
        // Ombra più leggera (offset di 1 pixel)
        g2.setColor(shadowColor);
        g2.drawString(String.valueOf(points), x + 1, y + 1);
        
        // ✅ TESTO PRINCIPALE GIALLO (SENZA IL "+")
        g2.setColor(textColor);
        g2.drawString(String.valueOf(points), x, y);
    }

    public boolean isExpired() {
        return System.currentTimeMillis() - startTime > DURATION;
    }
}