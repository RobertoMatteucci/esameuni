import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cloud {
    private Image[] cloudImages;  // Due immagini per l'animazione
    private int x, y;             // Posizione della nuvola
    private int width, height;    // Dimensioni della nuvola
    private boolean useSecondImage = false;  
    private Timer animationTimer;
    private Timer movementTimer;
    private int moveSpeed = 2; // Velocità di movimento iniziale lungo l'asse Y

    public Cloud(Image image1, Image image2, int x, int y, int width, int height) {
        cloudImages = new Image[]{image1, image2};
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        // Timer per l'animazione dell'immagine della nuvola
        animationTimer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                useSecondImage = !useSecondImage;
            }
        });
        animationTimer.start();
    }
    
    public void draw(Graphics2D g2) {
        g2.drawImage(cloudImages[useSecondImage ? 1 : 0], x, y, width, height, null);
    }

    public void move(int deltaY) {
        this.y -= deltaY; // 🔥 Muove la nuvola verso l'alto di deltaY pixel
    }
    
    // Imposta la velocità di movimento delle nuvole
    public void setMoveSpeed(int speed) {
        this.moveSpeed = speed;
    }

    public int getMoveSpeed() {
        return moveSpeed;
    }

    // Getters e setters per la posizione
    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
}
