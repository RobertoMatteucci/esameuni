import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ScoreManager {
    private int score = 0;
    private final int MAX_DIGITS = 6;
    private BufferedImage[] digitImages = new BufferedImage[10];

    public ScoreManager() {
        loadDigitImages();
    }

    private void loadDigitImages() {
        for (int i = 0; i < 10; i++) {
            try {
                String path = "/map/digits" + i + ".png";
                var stream = getClass().getResourceAsStream(path);
                if (stream == null) {
                    System.err.println(" Immagine non trovata: " + path);
                    continue;
                }
                digitImages[i] = ImageIO.read(stream);
                System.out.println("✅ Immagine caricata: " + path);
            } catch (IOException e) {
                System.err.println("Errore nel caricare l'immagine: " + i + ".png");
                e.printStackTrace();
            }
        }
    }

    public void addPoints(int points) {
        score += points;
        if (score > 999999) {
            score = 999999;
        }
    }

    public int getScore() {
        return score;
    }

    public void draw(Graphics2D g2, int x, int y) {
        String scoreString = String.format("%06d", score);
        for (int i = 0; i < scoreString.length(); i++) {
            int digit = Character.getNumericValue(scoreString.charAt(i));
            g2.drawImage(digitImages[digit], x + i * 55, y, 40, 50, null);
        }
    }

    public void reset() {
        score = 0;
    }
}
