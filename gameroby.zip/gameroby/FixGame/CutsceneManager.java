import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

public class CutsceneManager {

    private GamePanel gp;
    private Image[] backgrounds;
    private Image nuvola1, nuvola2;
    private Cloud[] clouds, clouds1, clouds2, clouds3, clouds4, clouds5, clouds6;

    private int currentBackground = 0;
    private CraneManager craneManager;
    private RalphCutscene ralphCutscene;
    private RalphCutscene2 ralphCutscene2;
    private VictoryCutscene victoryCutscene;
    private FelixIntroCutscene felixIntroCutscene;
    private CitizensCutscene citizensCutscene; // ✅ AGGIUNTA
    
    private boolean ralphSceneActive = false;
    private boolean ralphFinished = false;

    // Variabili per la cutscene finale "YOU FIXED IT"
    private boolean finalCutsceneActive = false;
    private long finalCutsceneStartTime;
    private final int FINAL_TEXT_DURATION = 3000;
    private long lastColorChange = 0;
    private Color currentColor = Color.YELLOW;

    public enum CutsceneType {
        NONE,
        INTRO,
        CITIZENS,        // ✅ AGGIUNTO NUOVO STATO
        FELIX_INTRO,
        RALPH_CLIMB,
        YOU_FIXED_IT,
        VICTORY
    }
    
    private CutsceneType activeCutscene = CutsceneType.INTRO;

    // Gestione timing tramite game loop (non Swing Timer)
    private int backgroundTimer = 0;
    private int craneTimer = 0;
    private static final int BACKGROUND_CHANGE_DELAY = 30; // ~1 secondo a 30 FPS
    private static final int CRANE_UPDATE_DELAY = 1; // Ogni frame

    public CutsceneManager(GamePanel gp) {
        this.gp = gp;
        this.craneManager = new CraneManager();
        this.victoryCutscene = new VictoryCutscene();
        this.ralphCutscene2 = new RalphCutscene2(655, 135, -50, 4, gp);
        loadImages();
        createClouds();
        ralphCutscene = new RalphCutscene(430, 692, 10, 10, 910, 453, 385, 140, 648);
        this.felixIntroCutscene = new FelixIntroCutscene(gp.player, gp);
        this.citizensCutscene = new CitizensCutscene(gp); // ✅ INIZIALIZZAZIONE
        
        startIntroCutscene();
    }

    private void loadImages() {
        try {
            backgrounds = new Image[8];
            backgrounds[0] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo0.png"));
            backgrounds[1] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo1.png"));
            backgrounds[2] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo2.png"));
            backgrounds[3] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo3.png"));
            backgrounds[4] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo3.png"));
            backgrounds[5] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo3.png"));
            backgrounds[6] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo3.png"));
            backgrounds[7] = ImageIO.read(getClass().getResourceAsStream("/map/Palazzo4.png"));

            nuvola1 = ImageIO.read(getClass().getResourceAsStream("/map/Nuvola1.png"));
            nuvola2 = ImageIO.read(getClass().getResourceAsStream("/map/Nuvola2.png"));
            
            System.out.println("CutsceneManager: Immagini caricate con successo");
        } catch (IOException e) {
            System.err.println("CutsceneManager: Errore nel caricamento delle immagini");
            e.printStackTrace();
        }
    }

    private void createClouds() {
        clouds = new Cloud[4];
        clouds1 = new Cloud[3];
        clouds2 = new Cloud[4];
        clouds3 = new Cloud[3];
        clouds4 = new Cloud[4];
        clouds5 = new Cloud[3];
        clouds6 = new Cloud[4];

        for (int i = 0; i < clouds.length; i++) {
            int x = 430 + i * 150, y = 750;
            clouds[i] = new Cloud(nuvola1, nuvola2, x, y, 150, 100);
            clouds2[i] = new Cloud(nuvola1, nuvola2, x, y - 50, 150, 100);
            clouds4[i] = new Cloud(nuvola1, nuvola2, x, y - 100, 150, 100);
            clouds6[i] = new Cloud(nuvola1, nuvola2, x, y - 150, 150, 100);
        }

        for (int i = 0; i < clouds1.length; i++) {
            int x = 430 + i * 150, y = 725;
            clouds1[i] = new Cloud(nuvola1, nuvola2, x + 75, y, 150, 100);
            clouds3[i] = new Cloud(nuvola1, nuvola2, x + 75, y - 75, 150, 100);
            clouds5[i] = new Cloud(nuvola1, nuvola2, x + 75, y - 125, 150, 100);
        }
    }

    private void moveClouds() {
        for (Cloud[] group : new Cloud[][] {clouds, clouds1, clouds2, clouds3, clouds4, clouds5, clouds6}) {
            for (Cloud cloud : group) {
                cloud.move(270);
            }
        }
    }

    private void startIntroCutscene() {
        activeCutscene = CutsceneType.INTRO;
        gp.ralph.setActive(false);
        backgroundTimer = 0;
        craneTimer = 0;
        loadAllSounds();
    }

    private void loadAllSounds() {
        SoundEffects.loadSound("die0", "snd/die0.wav");
        SoundEffects.loadSound("die1", "snd/die1.wav");
        SoundEffects.loadSound("jump", "snd/jump.wav");
        SoundEffects.loadSound("jumpdown", "snd/jumpdown.wav");
        SoundEffects.loadSound("block", "snd/block.wav");
        SoundEffects.loadSound("hammer", "snd/hammer.wav");
        SoundEffects.loadSound("voice0", "snd/voice0.wav");
        SoundEffects.loadSound("voice4", "snd/voice4.wav");
    }

    public void update() {
        switch (activeCutscene) {
            case INTRO:
                updateIntroCutscene();
                break;
                
            // ✅ AGGIUNTO CASE PER CITIZENS
            case CITIZENS:
                citizensCutscene.update();
                if (citizensCutscene.isFinished()) {
                    startFelixIntroCutscene(); // Passa alla cutscene di Felix
                }
                break;
                
            case FELIX_INTRO:
                felixIntroCutscene.update();
                if (felixIntroCutscene.isFinished()) {
                    activeCutscene = CutsceneType.NONE;
                    gp.ralph.setActive(true);
                    gp.player.setActive(true);
                }
                break;
                
            case RALPH_CLIMB:
                ralphCutscene2.update();
                if (ralphCutscene2.isFinished()) {
                    activeCutscene = CutsceneType.NONE;
                    gp.ralph.setActive(true);
                    ralphCutscene2.reset();
                }
                break;
                
            case YOU_FIXED_IT:
                long now = System.currentTimeMillis();
                if (now - finalCutsceneStartTime >= FINAL_TEXT_DURATION) {
                    finalCutsceneActive = false;
                    startVictoryCutscene();
                }
                
                if (now - lastColorChange >= 250) {
                    currentColor = new Color(
                        (int) (Math.random() * 255),
                        (int) (Math.random() * 255),
                        (int) (Math.random() * 255)
                    );
                    lastColorChange = now;
                }
                break;
                
            case VICTORY:
                victoryCutscene.update();
                if (victoryCutscene.isCompleted()) {
                    activeCutscene = CutsceneType.NONE;
                }
                break;
                
            case NONE:
                break;
        }
    }
    
    private void updateIntroCutscene() {
        backgroundTimer++;
        
        if (backgroundTimer >= BACKGROUND_CHANGE_DELAY && (!ralphSceneActive || ralphFinished)) {
            backgroundTimer = 0;
            currentBackground++;
            
            if (currentBackground == 4) {
                ralphSceneActive = true;
                ralphFinished = false;
            }
            
            // ✅ MODIFICATO: quando Ralph finisce, avvia la cutscene degli abitanti
            if (currentBackground >= 8 && ralphFinished) {
                startCitizensCutscene(); // Invece di startFelixIntroCutscene()
                return;
            }
            
            moveClouds();
        }
        
        craneTimer++;
        if (craneTimer >= CRANE_UPDATE_DELAY) {
            craneTimer = 0;
            
            if (ralphSceneActive && !ralphFinished) {
                ralphCutscene.update();
                
                if (ralphCutscene.getPhase() == 7) {
                    ralphFinished = true;
                    ralphSceneActive = false;
                    currentBackground = 6;
                    backgroundTimer = 0;
                }
            }
            
            craneManager.update();
        }
    }

    public void draw(Graphics2D g2) {
        switch (activeCutscene) {
            case INTRO:
                drawIntroCutscene(g2);
                break;
                
            // ✅ AGGIUNTO CASE PER DISEGNARE CITIZENS
            case CITIZENS:
                drawCitizensBackground(g2);
                citizensCutscene.draw(g2);
                break;
                
            case FELIX_INTRO:
                drawFelixIntroBackground(g2);
                felixIntroCutscene.draw(g2);
                break;
                
            case RALPH_CLIMB:
                drawRalphClimbCutscene(g2);
                break;
                
            case YOU_FIXED_IT:
                drawYouFixedItCutscene(g2);
                break;
                
            case VICTORY:
                victoryCutscene.draw(g2, gp.screenWidth, gp.screenHeight);
                break;
                
            case NONE:
                break;
        }
    }

    private void drawIntroCutscene(Graphics2D g2) {
        if (currentBackground < backgrounds.length && backgrounds[currentBackground] != null) {
            g2.drawImage(backgrounds[currentBackground], 401, 21, 651, 825, null);
        }

        if (currentBackground < 7) {
            for (Cloud[] group : new Cloud[][] {clouds, clouds1, clouds2, clouds3, clouds4, clouds5, clouds6}) {
                for (Cloud cloud : group) {
                    cloud.draw(g2);
                }
            }
        }

        if (ralphSceneActive && !ralphFinished) {
            ralphCutscene.draw(g2);
        } else if (ralphFinished && currentBackground >= 6 && currentBackground < 8) {
            ralphCutscene.draw(g2);
        }

        if (currentBackground < 7) {
            craneManager.draw(g2);
        }
    }
    
    // ✅ NUOVO METODO PER DISEGNARE LO SFONDO DELLA CUTSCENE CITIZENS
    private void drawCitizensBackground(Graphics2D g2) {
        // Disegna l'ultimo background (palazzo completo)
        if (backgrounds[7] != null) {
            g2.drawImage(backgrounds[7], 401, 21, 651, 825, null);
        }

        // Disegna Ralph fermo con le braccia alzate
        if (ralphFinished && ralphCutscene != null) {
            ralphCutscene.draw(g2);
        }
    }
    
    private void drawFelixIntroBackground(Graphics2D g2) {
        if (backgrounds[7] != null) {
            g2.drawImage(backgrounds[7], 401, 21, 651, 825, null);
        }

        if (ralphFinished && ralphCutscene != null) {
            ralphCutscene.draw(g2);
        }
    }

    private void drawRalphClimbCutscene(Graphics2D g2) {
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, gp.getWidth(), gp.getHeight());
        ralphCutscene2.draw(g2);
    }

    private void drawYouFixedItCutscene(Graphics2D g2) {
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, gp.getWidth(), gp.getHeight());

        try {
            InputStream is = getClass().getResourceAsStream("/res/fonts/PressStart2P.ttf");
            Font arcadeFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(36f);
            g2.setFont(arcadeFont);
        } catch (Exception e) {
            g2.setFont(new Font("Monospaced", Font.BOLD, 60));
        }
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);

        String text = "YOU FIXED IT";
        int x = 480;
        int y = 400;

        g2.setColor(currentColor);
        g2.drawString(text, x, y);
    }

    // ✅ NUOVO METODO PER AVVIARE LA CUTSCENE DEGLI ABITANTI
    public void startCitizensCutscene() {
        System.out.println("🎬 Avvio cutscene Citizens");
        activeCutscene = CutsceneType.CITIZENS;
        gp.player.setActive(false);
        gp.ralph.setActive(false);
        citizensCutscene.start();
    }

    public void startFelixIntroCutscene() {
        System.out.println("🎬 Avvio cutscene Felix Intro");
        activeCutscene = CutsceneType.FELIX_INTRO;
        gp.player.setActive(false);
        gp.ralph.setActive(false);
        felixIntroCutscene.start();
    }

    public void startRalphClimbCutscene() {
        System.out.println("🎬 Avvio cutscene Ralph salita");
        activeCutscene = CutsceneType.RALPH_CLIMB;
        ralphCutscene2.reset();
        gp.ralph.stopAndClear();
    }

    public void startYouFixedItCutscene() {
        System.out.println("🎬 Avvio cutscene YOU FIXED IT");
        activeCutscene = CutsceneType.YOU_FIXED_IT;
        finalCutsceneActive = true;
        finalCutsceneStartTime = System.currentTimeMillis();
        lastColorChange = finalCutsceneStartTime;
    }

    public void startVictoryCutscene() {
        System.out.println("🎬 Avvio victory cutscene");
        activeCutscene = CutsceneType.VICTORY;
        victoryCutscene.start();
    }

    public boolean isAnyCutsceneActive() {
        return activeCutscene != CutsceneType.NONE;
    }

    public boolean isIntroCutsceneFinished() {
        return activeCutscene == CutsceneType.NONE || 
               (currentBackground >= 8 && ralphFinished);
    }

    public CutsceneType getActiveCutscene() {
        return activeCutscene;
    }
    
    public void cleanup() {
        if (ralphCutscene != null) {
            ralphCutscene.reset();
        }
        if (ralphCutscene2 != null) {
            ralphCutscene2.reset();
        }
        if (felixIntroCutscene != null) {
            felixIntroCutscene.start();
        }
        if (citizensCutscene != null) {
            citizensCutscene.reset();
        }
        
        ralphSceneActive = false;
        ralphFinished = false;
        currentBackground = 0;
        backgroundTimer = 0;
        craneTimer = 0;
    }
}