import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;

public class RalphCutscene2 {

    private GamePanel gp;
    private int x, y;
    private int finalY;
    private int speed;
    private boolean finished = false;

    private Image frame1, frame2, frame3;
    private int frameCounter = 0;
    private int frameDelay = 10;

    public RalphCutscene2(int startX, int startY, int finalY, int speed, GamePanel gp) {
        this.gp = gp;
        this.x = startX;
        this.y = startY;
        this.finalY = finalY;
        this.speed = speed;

        try {
            frame1 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack1.png"));
            frame2 = ImageIO.read(getClass().getResourceAsStream("/ralph/RalphBack2.png"));
            frame3 = ImageIO.read(getClass().getResourceAsStream("/ralph/Move9.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        if (finished) {
            return;
        }

        if (y > finalY) {
            y -= speed;
        } else {
            y = finalY;
            gp.ralph.x = 644;
            finished = true;
        }

        frameCounter++;
    }

    public void draw(Graphics2D g2) {

        Image currentFrame = (frameCounter / frameDelay) % 2 == 0 ? frame1 : frame2;
        int width = 180;
        int height = 180;
        g2.drawImage(currentFrame, x, y, width, height, null);
    }

    public boolean isFinished() {
        return finished;
    }

    public void reset() {
        finished = false;
        frameCounter = 0;
        y = 135; // valore iniziale compatibile con Ralph in basso
    }
}
